const SALES_ORDER_KEY = 'orders';
const SALES_ORDER_STATUSES = [
  'Pending',
  'Quoted',
  'Shipped',
  'Delivered',
  'Rejected'
];


const demoOrders = [
  {
    id: 1001,
    customerName: "test user 1",
    customerEmail: "customer@example.com",
    items: [
      { toyId: 1, name: "Educational Robot Kit", price: 89.99, quantity: 1 },
      { toyId: 5, name: "Building Blocks Set", price: 39.99, quantity: 2 }
    ],
    total: 169.97,
    status: "delivered",
    orderDate: "2025-01-15",
    estimatedDelivery: "2025-01-20",
    shippingAddress: "123 Main St, Hong Kong",
    shippingMethod: "standard"
  },
  {
    id: 1002,
    customerName: "test user 2",
    customerEmail: "roryisgoated@example.com",
    items: [
      { toyId: 3, name: "Creative Art Station", price: 129.99, quantity: 1 }
    ],
    total: 129.99,
    status: "processing",
    orderDate: "2025-03-10",
    estimatedDelivery: "2025-03-17",
    shippingAddress: "123 Main St, Hong Kong",
    shippingMethod: "express"
  }
];

let salesOrders = [];
let selectedOrderId = null;

// --- Storage helpers ---

function loadSalesOrders() {
  let stored = [];

  try {
    const raw = localStorage.getItem(SALES_ORDER_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    stored = Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    stored = [];
  }

  // merge demo w/o duplicating ids
  const existingIds = new Set(stored.map(o => o.id));
  const merged = stored.slice();

  demoOrders.forEach(o => {
    if (!existingIds.has(o.id)) {
      merged.push(o);
    }
  });

  salesOrders = merged;

  try {
    localStorage.setItem(SALES_ORDER_KEY, JSON.stringify(salesOrders));
  } catch (e) {
    // ignore
  }
}

function saveSalesOrders() {
  try {
    localStorage.setItem(SALES_ORDER_KEY, JSON.stringify(salesOrders));
  } catch (e) {
    // ignore
  }
}

function formatCurrency(amount) {
  const num = Number(amount || 0);
  return '$' + num.toFixed(2);
}

function formatDateDisplay(iso) {
  if (!iso) return '-';
  if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toISOString().slice(0, 10);
}

// Map customer-side status into one of SALES_ORDER_STATUSES
function getSalesStatus(order) {
  const base = (order && (order.salesStatus || order.status || '')).toString().toLowerCase();

  switch (base) {
    case 'pending':
      return 'Pending';
    case 'quoted':
      return 'Quoted';
    case 'shipped':
      return 'Shipped';
    case 'delivered':
      return 'Delivered';
    case 'rejected':
      return 'Rejected';
    default:
      return 'Pending';
  }
}

// --- Stats ---

function renderSalesStats() {
  const totalEl = document.getElementById('stat-total');
  const reqEl = document.getElementById('stat-requested');
  const confEl = document.getElementById('stat-confirmed');
  const shipEl = document.getElementById('stat-shipped');
  const delEl = document.getElementById('stat-delivered');

  const total = salesOrders.length;
  let pending = 0;
  let approved = 0;
  let shipped = 0;
  let delivered = 0;

  salesOrders.forEach(o => {
    const st = getSalesStatus(o);
    if (st === 'Pending') pending++;
    else if (st === 'Approved') approved++;
    else if (st === 'Shipped') shipped++;
    else if (st === 'Delivered') delivered++;
  });

  if (totalEl) totalEl.textContent = total;
  if (reqEl) reqEl.textContent = pending;
  if (confEl) confEl.textContent = approved;
  if (shipEl) shipEl.textContent = shipped;
  if (delEl) delEl.textContent = delivered;
}

// --- Table rendering ---

function renderOrdersTable() {
  const tbody = document.getElementById('orders-tbody');
  const emptyMsg = document.getElementById('orders-empty');
  if (!tbody) return;

  tbody.innerHTML = '';

  const statusFilter = document.getElementById('status-filter');
  const searchInput = document.getElementById('order-search');

  const filterVal = statusFilter ? statusFilter.value : 'all';
  const searchVal = (searchInput ? searchInput.value : '').toLowerCase().trim();

  const filtered = salesOrders.filter(order => {
    const status = getSalesStatus(order);

    if (filterVal && filterVal !== 'all' && status !== filterVal) {
      return false;
    }

    if (searchVal) {
      const idStr = (order.id || '').toString().toLowerCase();
      const nameStr = (order.customerName || '').toString().toLowerCase();
      const emailStr = (order.customerEmail || '').toString().toLowerCase();
      if (!idStr.includes(searchVal) && !nameStr.includes(searchVal) && !emailStr.includes(searchVal)) {
        return false;
      }
    }

    return true;
  });

  if (!filtered.length) {
    if (emptyMsg) emptyMsg.classList.remove('hidden');
    return;
  }

  if (emptyMsg) emptyMsg.classList.add('hidden');

  filtered.forEach(order => {
    const tr = document.createElement('tr');
    tr.className = 'sales-row';

    const status = getSalesStatus(order);
    const created = formatDateDisplay(order.orderDate);
    const eta = formatDateDisplay(order.estimatedDelivery);

    tr.innerHTML = `
      <td>#${order.id}</td>
      <td>
        <div class="order-customer-name">${order.customerName || 'Unknown customer'}</div>
        <div class="order-customer-email">${order.customerEmail || ''}</div>
      </td>
      <td>
        <span class="order-status-chip status-${status.replace(/\s+/g, '-').toLowerCase()}">
          ${status}
        </span>
      </td>
      <td>${created}</td>
      <td>${eta}</td>
    `;

    tr.addEventListener('click', function() {
      showOrderDetail(order.id);
    });

    tbody.appendChild(tr);
  });
}

// --- Detail panel ---

function showOrderDetail(orderId) {
  const order = salesOrders.find(o => String(o.id) === String(orderId));
  const empty = document.getElementById('detail-empty');
  const content = document.getElementById('detail-content');

  if (!order || !empty || !content) return;

  selectedOrderId = order.id;

  empty.classList.add('hidden');
  content.classList.remove('hidden');

  const idEl = document.getElementById('detail-id');
  const custEl = document.getElementById('detail-customer');
  const emailEl = document.getElementById('detail-email');
  const phoneEl = document.getElementById('detail-phone');
  const addrEl = document.getElementById('detail-address');
  const itemsList = document.getElementById('detail-items-list');
  const statusSelect = document.getElementById('detail-status-select');
  const etaInput = document.getElementById('detail-estimated-delivery');
  const timelineList = document.getElementById('detail-timeline-list');

  if (idEl) idEl.textContent = '#' + order.id;
  if (custEl) custEl.textContent = order.customerName || 'Unknown customer';
  if (emailEl) emailEl.textContent = order.customerEmail || '-';
  if (phoneEl) phoneEl.textContent = order.customerPhone || '-';
  if (addrEl) addrEl.textContent = order.shippingAddress || '-';

  if (itemsList) {
    itemsList.innerHTML = '';
    (order.items || []).forEach(item => {
      const li = document.createElement('li');
      const qty = item.quantity || 1;
      li.textContent = `${item.name || 'Item'} x${qty} – ${formatCurrency(item.price)} each`;
      itemsList.appendChild(li);
    });
  }

  const status = getSalesStatus(order);
  if (statusSelect) {
    statusSelect.value = status;
  }
  if (etaInput) {
    etaInput.value = order.estimatedDelivery || '';
  }

  if (timelineList) {
    timelineList.innerHTML = '';
    const history = order.salesHistory || [];
    if (!history.length) {
      const li = document.createElement('li');
      li.textContent = 'No history yet.';
      timelineList.appendChild(li);
    } else {
      history.forEach(entry => {
        const li = document.createElement('li');
        const ts = entry.timestamp ? formatDateDisplay(entry.timestamp) : '';
        li.textContent = `${entry.status} – ${ts}`;
        timelineList.appendChild(li);
      });
    }
  }
}

// --- Save / update ---

function handleSaveDetail() {
  if (!selectedOrderId) return;

  const order = salesOrders.find(o => String(o.id) === String(selectedOrderId));
  if (!order) return;

  const statusSelect = document.getElementById('detail-status-select');
  const etaInput = document.getElementById('detail-estimated-delivery');

  const newStatus = statusSelect ? statusSelect.value : getSalesStatus(order);
  const newEta = etaInput ? etaInput.value : '';

  // write back to the same field the customer side uses
  order.status = newStatus;

  if (newEta) {
    order.estimatedDelivery = newEta;
  }

  // keep simple history for sales
  if (!order.salesHistory) {
    order.salesHistory = [];
  }
  order.salesHistory.push({
    status: newStatus,
    timestamp: new Date().toISOString()
  });

  saveSalesOrders();
  renderSalesStats();
  renderOrdersTable();
  showOrderDetail(order.id);

  if (typeof showNotification === 'function') {
    showNotification('Order updated and customer view refreshed.', 'success');
  }
}


// --- Entry point ---

function loadSalesDashboard() {
  // show current user name if available
  try {
    const rawUser = localStorage.getItem('currentUser');
    if (rawUser) {
      const user = JSON.parse(rawUser);
      const nameEl = document.getElementById('sales-name');
      if (nameEl && user && user.name) {
        nameEl.textContent = user.name;
      }
    }
  } catch (e) {
    // ignore
  }

  loadSalesOrders();
  renderSalesStats();
  renderOrdersTable();

  const statusFilter = document.getElementById('status-filter');
  const searchInput = document.getElementById('order-search');
  const saveBtn = document.getElementById('detail-save-btn');

  if (statusFilter) {
    statusFilter.addEventListener('change', renderOrdersTable);
  }
  if (searchInput) {
    searchInput.addEventListener('input', renderOrdersTable);
  }
  if (saveBtn) {
    saveBtn.addEventListener('click', handleSaveDetail);
  }
}

function initSalesPage() {
  try {
    const saved = JSON.parse(localStorage.getItem('currentUser') || 'null');

    // must be logged in as sales
    if (!saved || saved.type !== 'sales') {
      window.location.href = '../index.html'; // same redirect style as script.js
      return;
    }

    // show name on this page
    const nameEls = document.querySelectorAll('#current-user-name, #sales-name');
    nameEls.forEach(el => {
      if (el) el.textContent = saved.name || 'Sales User';
    });

  } catch (e) {
    window.location.href = '../index.html';
    return;
  }

  // now load the sales dashboard (orders from localStorage)
  loadSalesDashboard();
}

document.addEventListener('DOMContentLoaded', initSalesPage);

function logout() {
  const ok = window.confirm('Are you sure you want to log out?');
  if (!ok) return;

  // Back to login / landing
  window.location.href = '../index.html';
}

// Expose for script.js
window.loadSalesDashboard = loadSalesDashboard;
window.logout = logout;