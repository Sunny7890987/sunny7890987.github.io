// Quote Request JavaScript
let currentDesign = null;

$(document).ready(function() {
    initializeQuoteRequest();
    $('#quote-request-form').on('submit', handleQuoteRequest);
});

function initializeQuoteRequest() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        window.location.href = '../index.html';
        return;
    }
    
    $('#current-user-name').text(currentUser.name);
    
    // Get design ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const designId = urlParams.get('designId');
    
    if (!designId) {
        showNotification('No design selected. Please create a custom toy first.', 'error');
        setTimeout(() => {
            window.location.href = 'custom-builder.html';
        }, 2000);
        return;
    }
    
    // Load design data
    loadDesign(designId);
}

function loadDesign(designId) {
    const designs = JSON.parse(localStorage.getItem('toyDesigns') || '[]');
    currentDesign = designs.find(design => design.id === designId);
    
    if (!currentDesign) {
        showNotification('Design not found. Please create a new design.', 'error');
        setTimeout(() => {
            window.location.href = 'custom-builder.html';
        }, 2000);
        return;
    }
    
    displayDesignPreview(currentDesign);
}

function displayDesignPreview(design) {
    const preview = $('#design-preview');
    
    const safetyFeatures = design.safetyFeatures?.join(', ') || 'None';
    const specialFeatures = design.specialFeatures?.join(', ') || 'None';
    
    preview.html(`
        <h3>Design Preview</h3>
        <div class="preview-grid">
            <div class="preview-section">
                <h4>Basic Information</h4>
                <p><strong>Toy Name:</strong> ${design.toyName}</p>
                <p><strong>Type:</strong> ${design.toyType}</p>
                <p><strong>Quantity:</strong> ${design.quantity}</p>
                <p><strong>Age Group:</strong> ${design.targetAge}</p>
            </div>
            <div class="preview-section">
                <h4>Design Specifications</h4>
                <p><strong>Description:</strong> ${design.designDescription}</p>
                ${design.sketch ? `<p><strong>Sketch:</strong> Provided</p>` : ''}
            </div>
            <div class="preview-section">
                <h4>Materials & Features</h4>
                <p><strong>Material:</strong> ${design.materialType}</p>
                <p><strong>Stuffing:</strong> ${design.stuffingMaterial}</p>
                <p><strong>Safety:</strong> ${safetyFeatures}</p>
            </div>
            <div class="preview-section">
                <h4>Special Features</h4>
                <p><strong>Features:</strong> ${specialFeatures}</p>
                <p><strong>Additional:</strong> ${design.additionalRequirements || 'None'}</p>
            </div>
        </div>
    `);
}

function handleQuoteRequest(event) {
    event.preventDefault();
    
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const formData = new FormData(event.target);
    const formDataObj = Object.fromEntries(formData.entries());
    const estimatedCompletion = QuotationData.calculateEstimatedCompletion(formDataObj.urgencyLevel);
    
    const quoteRequest = QuotationData.createQuoteRequest({
        design: currentDesign,
        customer: currentUser,
        preferences: {
            ...formDataObj,
            estimatedCompletion
        }
    });
    
    showNotification(`Quote request ${quoteRequest.id} submitted! Estimated completion ${formatDate(quoteRequest.estimatedCompletion)}.`, 'success');
    
    setTimeout(() => {
        window.location.href = 'quote-tracking.html?requestId=' + quoteRequest.id;
    }, 1800);
}

function goBack() {
    window.location.href = 'custom-builder.html';
}

function showNotification(message, type = 'success') {
    alert(`${type.toUpperCase()}: ${message}`);
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}

function formatDate(dateString) {
    if (!dateString) return 'Not set';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}