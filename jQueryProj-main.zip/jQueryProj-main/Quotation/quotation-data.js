(function(window) {
    const STORAGE_KEYS = {
        requests: 'quoteRequests',
        quotations: 'quotations',
        designs: 'toyDesigns',
        seedFlag: 'quotationSeededV2'
    };

    const demoQuoteRequests = [
        {
            id: 'QR1203',
            designId: 'TD9001',
            toyName: 'STEM Explorer Bot',
            toyType: 'electronic',
            customerName: 'John Doe',
            customerEmail: 'customer@example.com',
            quantity: 100,
            targetAge: '7-12',
            status: 'quoted',
            submittedDate: '2025-02-10',
            estimatedCompletion: '2025-03-01',
            budgetRange: '101-200',
            urgencyLevel: 'express',
            paymentMethod: 'credit-card',
            deliveryDate: '2025-03-25',
            designDescription: 'Programmable educational robot with LED feedback.',
            materialType: 'plastic',
            stuffingMaterial: 'none',
            safetyFeatures: ['non-toxic', 'no-small-parts'],
            specialFeatures: ['lights', 'sound'],
            history: [
                { status: 'pending', timestamp: '2025-02-10T09:00:00Z', notes: 'Request submitted' },
                { status: 'reviewing', timestamp: '2025-02-11T09:30:00Z', notes: 'Sales started requirement review' },
                { status: 'quoted', timestamp: '2025-02-12T14:20:00Z', notes: 'Quote Q5001 issued' }
            ],
            conversation: [
                { id: 'MSG1001', role: 'system', author: 'Smile & Sunshine', message: 'Thank you for submitting your tailor-made quotation request. Our sales personnel will review it shortly.', timestamp: '2025-02-10T09:00:30Z' },
                { id: 'MSG1002', role: 'sales', author: 'Jane Smith', message: 'Hi John, quotation Q5001 has been shared with an estimated production time of 14 days.', timestamp: '2025-02-12T14:30:00Z' }
            ],
            quoteAmount: 7550,
            quotePerPiece: 75.5,
            quoteBreakdown: 'Base: $55 • Materials: $10 • Labor: $8 • Special features: $2.5',
            quoteId: 'Q5001',
            quoteDate: '2025-02-12',
            validUntil: '2025-03-15',
            productionTime: 14
        },
        {
            id: 'QR1305',
            designId: 'TD9002',
            toyName: 'Eco Plush Dragon',
            toyType: 'plush',
            customerName: 'Mary Lee',
            customerEmail: 'mary@example.com',
            quantity: 50,
            targetAge: '4-6',
            status: 'pending',
            submittedDate: '2025-03-05',
            estimatedCompletion: '2025-03-28',
            budgetRange: '51-100',
            urgencyLevel: 'standard',
            paymentMethod: 'bank-transfer',
            deliveryDate: '2025-04-08',
            designDescription: 'Hand-stitched plush dragon using recycled cotton.',
            materialType: 'cotton',
            stuffingMaterial: 'polyfill',
            safetyFeatures: ['non-toxic', 'washable'],
            specialFeatures: ['sound'],
            history: [
                { status: 'pending', timestamp: '2025-03-05T10:10:00Z', notes: 'Request submitted' }
            ],
            conversation: [
                { id: 'MSG1003', role: 'system', author: 'Smile & Sunshine', message: 'Your quote was received. We will assign it to a sales personnel shortly.', timestamp: '2025-03-05T10:10:30Z' }
            ]
        }
    ];

    const demoQuotations = [
        {
            id: 'Q5001',
            quoteRequestId: 'QR1203',
            customerEmail: 'customer@example.com',
            price: 75.5,
            validUntil: '2025-03-15',
            productionTime: 14,
            status: 'quoted',
            generatedDate: '2025-02-12',
            salesPerson: 'Jane Smith'
        }
    ];

    function ensureSeeded() {
        if (localStorage.getItem(STORAGE_KEYS.seedFlag)) return;
        localStorage.setItem(STORAGE_KEYS.requests, JSON.stringify(demoQuoteRequests));
        localStorage.setItem(STORAGE_KEYS.quotations, JSON.stringify(demoQuotations));
        localStorage.setItem(STORAGE_KEYS.seedFlag, '1');
    }

    function readCollection(key) {
        ensureSeeded();
        try {
            return JSON.parse(localStorage.getItem(key) || '[]');
        } catch (error) {
            console.error('[QuotationData] Failed to parse storage', error);
            return [];
        }
    }

    function writeCollection(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    function generateId(prefix = 'QR') {
        const random = Math.floor(Math.random() * 900 + 100);
        return `${prefix}${Date.now()}${random}`;
    }

    function calculateEstimatedCompletion(urgency = 'standard') {
        const date = new Date();
        switch (urgency) {
            case 'express':
                date.setDate(date.getDate() + 7);
                break;
            case 'urgent':
                date.setDate(date.getDate() + 3);
                break;
            default:
                date.setDate(date.getDate() + 21);
        }
        return date.toISOString().split('T')[0];
    }

    function getQuoteRequests() {
        return readCollection(STORAGE_KEYS.requests);
    }

    function getQuotations() {
        return readCollection(STORAGE_KEYS.quotations);
    }

    function saveQuoteRequests(requests) {
        writeCollection(STORAGE_KEYS.requests, requests);
    }

    function saveQuotations(quotations) {
        writeCollection(STORAGE_KEYS.quotations, quotations);
    }

    function getQuoteRequestById(id) {
        return getQuoteRequests().find(request => request.id === id) || null;
    }

    function getRequestsByCustomer(email) {
        return getQuoteRequests().filter(request => request.customerEmail === email);
    }

    function addHistoryEntry(request, status, notes = '') {
        const timestamp = new Date().toISOString();
        request.history = request.history || [];
        request.history.push({ status, timestamp, notes });

        switch (status) {
            case 'pending':
                request.submittedDate = request.submittedDate || timestamp;
                break;
            case 'reviewing':
                request.reviewDate = timestamp;
                break;
            case 'quoted':
                request.quoteDate = timestamp;
                break;
            case 'approved':
                request.approvalDate = timestamp;
                break;
            case 'rejected':
                request.rejectionDate = timestamp;
                break;
            default:
                break;
        }
    }

    function createSystemMessage(message) {
        return {
            id: generateId('MSG'),
            role: 'system',
            author: 'Smile & Sunshine',
            message,
            timestamp: new Date().toISOString()
        };
    }

    function createQuoteRequest({ design, preferences = {}, customer }) {
        const requests = getQuoteRequests();
        const request = {
            id: generateId('QR'),
            designId: design?.id || null,
            customerEmail: customer.email,
            customerName: customer.name,
            toyName: design?.toyName || preferences.toyName || 'Custom Toy',
            toyType: design?.toyType || preferences.toyType || 'custom',
            quantity: Number(design?.quantity || preferences.quantity || 1),
            targetAge: design?.targetAge || preferences.targetAge || '',
            materialType: design?.materialType || preferences.materialType || '',
            stuffingMaterial: design?.stuffingMaterial || preferences.stuffingMaterial || '',
            safetyFeatures: design?.safetyFeatures || [],
            specialFeatures: design?.specialFeatures || [],
            designDescription: design?.designDescription || '',
            budgetRange: preferences.budgetRange || '',
            urgencyLevel: preferences.urgencyLevel || 'standard',
            paymentMethod: preferences.paymentMethod || 'credit-card',
            deliveryDate: preferences.deliveryDate || '',
            specialInstructions: preferences.specialInstructions || '',
            status: 'pending',
            submittedDate: new Date().toISOString(),
            estimatedCompletion: preferences.estimatedCompletion || calculateEstimatedCompletion(preferences.urgencyLevel),
            sketch: design?.sketch || null
        };

        addHistoryEntry(request, 'pending', 'Request submitted');
        request.conversation = [
            createSystemMessage('Thank you for submitting your quotation request. A sales personnel will be assigned shortly.')
        ];

        requests.push(request);
        saveQuoteRequests(requests);
        return request;
    }

    function updateStatus(requestId, status, options = {}) {
        const requests = getQuoteRequests();
        const index = requests.findIndex(request => request.id === requestId);
        if (index === -1) return null;

        const request = requests[index];
        request.status = status;
        addHistoryEntry(request, status, options.notes);

        if (options.estimatedCompletion) {
            request.estimatedCompletion = options.estimatedCompletion;
        }

        requests[index] = request;
        saveQuoteRequests(requests);
        return request;
    }

    function submitQuote(requestId, data, salesPerson = 'Sales Team') {
        const requests = getQuoteRequests();
        const requestIndex = requests.findIndex(request => request.id === requestId);
        if (requestIndex === -1) return null;

        const request = requests[requestIndex];
        const perPiece = Number(data.perPiece || data.quotePrice || 0);
        const grandTotal = Number(data.grandTotal || perPiece * request.quantity || 0);

        const quotation = {
            id: generateId('Q'),
            quoteRequestId: requestId,
            customerEmail: request.customerEmail,
            price: perPiece,
            validUntil: data.validUntil || calculateEstimatedCompletion('standard'),
            productionTime: Number(data.productionTime || 14),
            status: 'quoted',
            generatedDate: new Date().toISOString(),
            salesPerson
        };

        request.status = 'quoted';
        request.quoteAmount = grandTotal;
        request.quotePerPiece = perPiece;
        request.quoteBreakdown = data.breakdown || data.quoteBreakdown || '';
        request.quoteNotes = data.quoteNotes || '';
        request.validUntil = quotation.validUntil;
        request.productionTime = quotation.productionTime;
        request.quoteId = quotation.id;

        if (data.estimatedCompletion) {
            request.estimatedCompletion = data.estimatedCompletion;
        }

        addHistoryEntry(request, 'quoted', `Quotation ${quotation.id} issued`);

        requests[requestIndex] = request;
        saveQuoteRequests(requests);

        const quotations = getQuotations();
        quotations.push(quotation);
        saveQuotations(quotations);

        return { request, quotation };
    }

    function addConversationMessage(requestId, payload) {
        if (!payload?.message?.trim()) return null;
        const requests = getQuoteRequests();
        const index = requests.findIndex(request => request.id === requestId);
        if (index === -1) return null;

        const request = requests[index];
        request.conversation = request.conversation || [];

        const message = {
            id: generateId('MSG'),
            role: payload.role || 'customer',
            author: payload.author || 'Unknown',
            message: payload.message.trim(),
            timestamp: new Date().toISOString()
        };

        request.conversation.push(message);
        requests[index] = request;
        saveQuoteRequests(requests);
        return request.conversation;
    }

    function getRecentConversations(limit = 5) {
        return getQuoteRequests()
            .flatMap(request => (request.conversation || []).map(entry => ({
                ...entry,
                requestId: request.id,
                toyName: request.toyName,
                status: request.status
            })))
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, limit);
    }

    window.QuotationData = {
        getQuoteRequests,
        getQuotations,
        getQuoteRequestById,
        getRequestsByCustomer,
        saveQuoteRequests,
        generateId,
        calculateEstimatedCompletion,
        createQuoteRequest,
        updateStatus,
        submitQuote,
        addConversationMessage,
        getRecentConversations
    };
})(window);

