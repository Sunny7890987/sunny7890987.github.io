// Quote Tracking JavaScript
let allQuoteRequests = [];
let currentUser = null;
let selectedRequest = null;

$(document).ready(function() {
    initializeTracking();
    
    // Event listeners for filters
    $('#search-requests').on('input', filterRequests);
    $('#status-filter').on('change', filterRequests);
    $('#conversation-form').on('submit', handleConversationSubmit);
});

function initializeTracking() {
    currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        window.location.href = '../index.html';
        return;
    }
    
    $('#current-user-name').text(currentUser.name);
    
    // Load quote requests
    loadQuoteRequests(currentUser.email);
    
    // Check if specific request is selected
    const urlParams = new URLSearchParams(window.location.search);
    const requestId = urlParams.get('requestId');
    
    if (requestId) {
        displayCurrentRequest(requestId);
    } else if (allQuoteRequests.length) {
        displayCurrentRequest(allQuoteRequests[0].id);
    }
}

function loadQuoteRequests(userEmail) {
    allQuoteRequests = QuotationData.getRequestsByCustomer(userEmail)
        .filter(request => request.customerEmail === userEmail)
        .sort((a, b) => new Date(b.submittedDate) - new Date(a.submittedDate));
    
    displayRequestsList(allQuoteRequests);
}

function displayCurrentRequest(requestId) {
    const request = allQuoteRequests.find(req => req.id === requestId);
    if (!request) {
        $('#current-request').html('<div class="empty-state">Select a quotation request to view details.</div>');
        $('#conversation-thread').html('<div class="empty-state">Select a request to view the conversation.</div>');
        selectedRequest = null;
        return;
    }
    
    selectedRequest = request;

    const currentRequestDiv = $('#current-request');
    const statusTimeline = generateStatusTimeline(request);
    
    currentRequestDiv.html(`
        <div class="request-header">
            <div class="request-id">${request.id} - ${request.toyName}</div>
            <div class="status-badge status-${request.status}">${request.status.toUpperCase()}</div>
        </div>
        
        <div class="request-details">
            <div class="detail-grid">
                <div class="detail-item">
                    <label>Submitted Date:</label>
                    <span>${formatDate(request.submittedDate)}</span>
                </div>
                <div class="detail-item">
                    <label>Estimated Completion:</label>
                    <span>${formatDate(request.estimatedCompletion)}</span>
                </div>
                <div class="detail-item">
                    <label>Quantity:</label>
                    <span>${request.quantity}</span>
                </div>
                <div class="detail-item">
                    <label>Budget Range:</label>
                    <span>${request.budgetRange || 'Not specified'}</span>
                </div>
            </div>
        </div>
        
        <div class="status-timeline">
            ${statusTimeline}
        </div>
        
        ${request.quoteAmount ? `
        <div class="quote-details">
            <h4>Quote Details</h4>
            <div class="quote-amount">
                <strong>Total Amount: $${request.quoteAmount}</strong>
                ${request.quoteBreakdown ? `
                <div class="breakdown">
                    ${request.quoteBreakdown}
                </div>
                ` : ''}
            </div>
        </div>
        ` : ''}
        <div class="request-actions" id="request-actions">
            ${renderRequestActions(request)}
        </div>
    `);

    renderConversationThread(request);
    highlightSelectedRequest();
}

function generateStatusTimeline(request) {
    const statuses = [
        { status: 'pending', label: 'Request Submitted', date: request.submittedDate },
        { status: 'reviewing', label: 'Under Review', date: request.reviewDate },
        { status: 'quoted', label: 'Quote Provided', date: request.quoteDate },
        { status: 'approved', label: 'Approved', date: request.approvalDate },
        { status: 'rejected', label: 'Rejected', date: request.rejectionDate }
    ];
    
    let timelineHTML = '';
    let foundCurrent = false;
    
    statuses.forEach((status, index) => {
        let stepClass = '';
        let date = '';
        const historyEntry = (request.history || []).find(record => record.status === status.status);
        
        if (historyEntry || status.date) {
            stepClass = 'completed';
            date = formatDate(historyEntry?.timestamp || status.date);
        } else if (!foundCurrent && getStatusIndex(request.status) >= index) {
            stepClass = 'current';
            foundCurrent = true;
            date = 'In progress';
        }
        
        timelineHTML += `
            <div class="timeline-step ${stepClass}">
                <h4>${status.label}</h4>
                ${date ? `<div class="timeline-date">${date}</div>` : ''}
                ${status.description ? `<p>${status.description}</p>` : ''}
            </div>
        `;
    });
    
    return timelineHTML;
}

function getStatusIndex(status) {
    const statusOrder = ['pending', 'reviewing', 'quoted', 'approved', 'rejected'];
    return statusOrder.indexOf(status);
}

function displayRequestsList(requests) {
    const requestsList = $('#requests-list');
    
    if (requests.length === 0) {
        requestsList.html('<div class="no-requests">No quote requests found.</div>');
        return;
    }
    
    requestsList.html(requests.map(request => `
        <div class="request-item ${selectedRequest?.id === request.id ? 'active' : ''}" onclick="displayCurrentRequest('${request.id}')">
            <div class="request-item-header">
                <div class="request-item-id">${request.id}</div>
                <div class="status-badge status-${request.status}">${request.status.toUpperCase()}</div>
            </div>
            <div class="request-item-details">
                <div>${request.toyName}</div>
                <div>Qty: ${request.quantity}</div>
                <div>${formatDate(request.submittedDate)}</div>
            </div>
        </div>
    `).join(''));
    
    highlightSelectedRequest();
}

function filterRequests() {
    const searchTerm = $('#search-requests').val().toLowerCase();
    const statusFilter = $('#status-filter').val();
    
    let filteredRequests = allQuoteRequests;
    
    if (searchTerm) {
        filteredRequests = filteredRequests.filter(request => 
            request.toyName.toLowerCase().includes(searchTerm) ||
            request.id.toLowerCase().includes(searchTerm)
        );
    }
    
    if (statusFilter !== 'all') {
        filteredRequests = filteredRequests.filter(request => request.status === statusFilter);
    }
    
    displayRequestsList(filteredRequests);
}

function formatDate(dateString) {
    if (!dateString) return 'Not set';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function renderRequestActions(request) {
    if (request.status === 'quoted') {
        return `
            <button class="btn btn-primary" onclick="acceptQuotation('${request.id}')">Accept quotation</button>
            <button class="btn btn-secondary" onclick="requestRevision('${request.id}')">Request revision</button>
        `;
    }
    if (request.status === 'approved') {
        return `<div class="pill success">Quotation approved • production will follow shortly.</div>`;
    }
    if (request.status === 'rejected') {
        return `<div class="pill warning">Quotation rejected • the sales team has been notified.</div>`;
    }
    return `<div class="pill info">We will notify you once the quotation is ready.</div>`;
}

function renderConversationThread(request) {
    const container = $('#conversation-thread');
    const conversation = request.conversation || [];
    
    if (conversation.length === 0) {
        container.html('<div class="empty-state">No messages yet. Start the conversation above.</div>');
        return;
    }
    
    container.html(conversation.map(message => `
        <div class="message ${message.role}">
            <div class="message-meta">
                <span>${message.author}</span>
                <span>${formatDate(message.timestamp)}</span>
            </div>
            <p>${message.message}</p>
        </div>
    `).join(''));
}

function handleConversationSubmit(event) {
    event.preventDefault();
    if (!selectedRequest) {
        showNotification('Select a quotation request first.', 'error');
        return;
    }
    
    const message = $('#conversation-message').val().trim();
    if (!message) return;
    
    QuotationData.addConversationMessage(selectedRequest.id, {
        author: currentUser.name,
        role: 'customer',
        message
    });
    
    $('#conversation-message').val('');
    refreshRequests(selectedRequest.id);
    showNotification('Message sent to the sales team!', 'success');
}

function acceptQuotation(requestId) {
    QuotationData.updateStatus(requestId, 'approved', { notes: 'Customer approved via tracking portal' });
    QuotationData.addConversationMessage(requestId, {
        author: currentUser.name,
        role: 'customer',
        message: 'Quotation approved. Please proceed to order confirmation.'
    });
    showNotification('Quotation approved! We will prepare the order.', 'success');
    refreshRequests(requestId);
}

function requestRevision(requestId) {
    QuotationData.updateStatus(requestId, 'reviewing', { notes: 'Customer requested a revision' });
    QuotationData.addConversationMessage(requestId, {
        author: currentUser.name,
        role: 'customer',
        message: 'Could you revise this quotation? I have follow-up questions.'
    });
    showNotification('Revision request sent to sales personnel.', 'success');
    refreshRequests(requestId);
}

function refreshRequests(requestId) {
    loadQuoteRequests(currentUser.email);
    displayCurrentRequest(requestId);
}

function highlightSelectedRequest() {
    $('.request-item').removeClass('active');
    if (selectedRequest) {
        $(`.request-item`).filter(function() {
            return $(this).find('.request-item-id').text() === selectedRequest.id;
        }).addClass('active');
    }
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}

function showNotification(message, type = 'success') {
    alert(`${type.toUpperCase()}: ${message}`);
}