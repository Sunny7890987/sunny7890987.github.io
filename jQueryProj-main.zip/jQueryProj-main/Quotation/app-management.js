// Application Management JavaScript
let allApplications = [];
let currentApplication = null;
let currentUser = null;
let quoteTotals = { perPiece: 0, grandTotal: 0 };

$(document).ready(function() {
    initializeManagement();
    
    $('#search-applications').on('input', filterApplications);
    $('#status-filter').on('change', filterApplications);
    $('#date-filter').on('change', filterApplications);
});

function initializeManagement() {
    currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        window.location.href = '../index.html';
        return;
    }
    
    $('#current-user-name').text(currentUser.name);
    loadApplications();
    
    // 检查URL参数，如果有applicationId则自动打开对应的申请详情
    const urlParams = new URLSearchParams(window.location.search);
    const applicationId = urlParams.get('applicationId');
    if (applicationId) {
        // 短暂延迟确保页面加载完成
        setTimeout(() => {
            viewApplication(applicationId);
        }, 500);
    }
}

function loadApplications() {
    allApplications = QuotationData.getQuoteRequests()
        .sort((a, b) => new Date(b.submittedDate) - new Date(a.submittedDate));
    
    updateStatistics();
    displayApplications(allApplications);
}

function updateStatistics() {
    const total = allApplications.length;
    const pending = allApplications.filter(app => app.status === 'pending').length;
    const quoted = allApplications.filter(app => app.status === 'quoted').length;
    const completed = allApplications.filter(app => app.status === 'approved').length;
    
    $('#total-requests').text(total);
    $('#pending-requests').text(pending);
    $('#quoted-requests').text(quoted);
    $('#completed-requests').text(completed);
}

function displayApplications(applications) {
    const tbody = $('#applications-tbody');
    
    if (applications.length === 0) {
        tbody.html('<tr><td colspan="7" class="no-data">No applications found.</td></tr>');
        return;
    }
    
    tbody.html(applications.map(app => `
        <tr>
            <td>${app.id}</td>
            <td>${app.customerName}</td>
            <td>${app.toyName}</td>
            <td>${app.quantity}</td>
            <td>${formatDate(app.submittedDate)}</td>
            <td><span class="status-badge status-${app.status}">${app.status.toUpperCase()}</span></td>
            <td>
                <div class="action-buttons">
                    <button class="btn-action btn-view" onclick="viewApplication('${app.id}')">View</button>
                    ${app.status === 'pending' ? `<button class="btn-action btn-quote" onclick="prepareQuote('${app.id}')">Quote</button>` : ''}
                    ${app.status === 'quoted' ? `<button class="btn-action btn-approve" onclick="updateStatus('${app.id}', 'approved')">Approve</button>` : ''}
                    ${app.status !== 'rejected' && app.status !== 'approved' ? `<button class="btn-action btn-reject" onclick="updateStatus('${app.id}', 'rejected')">Reject</button>` : ''}
                </div>
            </td>
        </tr>
    `).join(''));
}

function filterApplications() {
    const searchTerm = $('#search-applications').val().toLowerCase();
    const statusFilter = $('#status-filter').val();
    const dateFilter = $('#date-filter').val();
    
    let filteredApplications = allApplications;
    
    if (searchTerm) {
        filteredApplications = filteredApplications.filter(app => 
            app.toyName.toLowerCase().includes(searchTerm) ||
            app.customerName.toLowerCase().includes(searchTerm) ||
            app.id.toLowerCase().includes(searchTerm)
        );
    }
    
    if (statusFilter !== 'all') {
        filteredApplications = filteredApplications.filter(app => app.status === statusFilter);
    }
    
    if (dateFilter !== 'all') {
        const now = new Date();
        let startDate;
        
        switch(dateFilter) {
            case 'today':
                startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                break;
            case 'week':
                startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7);
                break;
            case 'month':
                startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
                break;
        }
        
        filteredApplications = filteredApplications.filter(app => 
            new Date(app.submittedDate) >= startDate
        );
    }
    
    displayApplications(filteredApplications);
}

function viewApplication(appId) {
    const applicationId = typeof appId === 'string' ? appId : appId.toString();
    currentApplication = allApplications.find(app => app.id === appId);
   if (!currentApplication) {
        console.warn('Application not found:', applicationId);
        showNotification('Application not found: ' + applicationId, 'error');
        return;
    }
    const newUrl = window.location.origin + window.location.pathname + '?applicationId=' + applicationId;
    window.history.pushState({}, '', newUrl);
    
    const modalBody = $('#modal-body');
    modalBody.html(`
        <div class="application-details">
            <div class="detail-section">
                <h4>Basic Information</h4>
                <div class="detail-item">
                    <span>Request ID:</span>
                    <span>${currentApplication.id}</span>
                </div>
                <div class="detail-item">
                    <span>Customer:</span>
                    <span>${currentApplication.customerName}</span>
                </div>
                <div class="detail-item">
                    <span>Email:</span>
                    <span>${currentApplication.customerEmail}</span>
                </div>
                <div class="detail-item">
                    <span>Toy Name:</span>
                    <span>${currentApplication.toyName}</span>
                </div>
                <div class="detail-item">
                    <span>Quantity:</span>
                    <span>${currentApplication.quantity}</span>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Design Details</h4>
                <div class="detail-item">
                    <span>Toy Type:</span>
                    <span>${currentApplication.toyType}</span>
                </div>
                <div class="detail-item">
                    <span>Age Group:</span>
                    <span>${currentApplication.targetAge}</span>
                </div>
                <div class="detail-item">
                    <span>Material:</span>
                    <span>${currentApplication.materialType}</span>
                </div>
                <div class="detail-item">
                    <span>Description:</span>
                    <span>${currentApplication.designDescription}</span>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Quote Preferences</h4>
                <div class="detail-item">
                    <span>Budget Range:</span>
                    <span>${currentApplication.budgetRange || 'Not specified'}</span>
                </div>
                <div class="detail-item">
                    <span>Urgency:</span>
                    <span>${currentApplication.urgencyLevel || 'Standard'}</span>
                </div>
                <div class="detail-item">
                    <span>Delivery Date:</span>
                    <span>${currentApplication.deliveryDate || 'Not specified'}</span>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Status Information</h4>
                <div class="detail-item">
                    <span>Current Status:</span>
                    <span class="status-badge status-${currentApplication.status}">${currentApplication.status.toUpperCase()}</span>
                </div>
                <div class="detail-item">
                    <span>Submitted:</span>
                    <span>${formatDate(currentApplication.submittedDate)}</span>
                </div>
                ${currentApplication.estimatedCompletion ? `
                <div class="detail-item">
                    <span>Est. Completion:</span>
                    <span>${formatDate(currentApplication.estimatedCompletion)}</span>
                </div>
                ` : ''}
            </div>
        </div>
        
        ${currentApplication.quoteAmount ? `
        <div class="detail-section">
            <h4>Quote Details</h4>
            <div class="detail-item">
                <span>Quote Amount:</span>
                <span><strong>$${currentApplication.quoteAmount}</strong></span>
            </div>
            ${currentApplication.quoteBreakdown ? `
            <div class="quote-breakdown">
                <h5>Breakdown:</h5>
                <pre>${currentApplication.quoteBreakdown}</pre>
            </div>
            ` : ''}
        </div>
        ` : ''}
        
        <div class="conversation-panel">
            <h4>Collaboration Thread</h4>
            <div class="message-thread" id="application-conversation"></div>
            <form class="message-form" id="sales-reply-form">
                <label for="sales-reply-message">Send a reply</label>
                <textarea id="sales-reply-message" rows="3" placeholder="Clarify open points or share updates..." required></textarea>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Send message</button>
                </div>
            </form>
        </div>
    `);
    
    const actionButtons = $('#action-buttons');
    let buttonsHTML = '';
    
    switch(currentApplication.status) {
        case 'pending':
            buttonsHTML = `
                <button class="btn btn-primary" onclick="prepareQuote('${currentApplication.id}')">Prepare Quote</button>
                <button class="btn btn-secondary" onclick="updateStatus('${currentApplication.id}', 'rejected')">Reject</button>
            `;
            break;
        case 'quoted':
            buttonsHTML = `
                <button class="btn btn-primary" onclick="updateStatus('${currentApplication.id}', 'approved')">Approve</button>
                <button class="btn btn-secondary" onclick="prepareQuote('${currentApplication.id}')">Modify Quote</button>
            `;
            break;
        default:
            buttonsHTML = '';
    }
    
    actionButtons.html(buttonsHTML);
    
    $('#application-modal').addClass('show');
    renderApplicationConversation();
    $('#sales-reply-form').on('submit', handleSalesReply);
    renderApplicationConversation();
    $('#sales-reply-form').on('submit', handleSalesReply);
    
    // 显示模态框
    $('#application-modal').addClass('show');
    
    // 自动滚动到对话部分
    setTimeout(() => {
        const conversationPanel = document.querySelector('.conversation-panel');
        if (conversationPanel) {
            conversationPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 300);
}

function prepareQuote(appId) {
    currentApplication = allApplications.find(app => app.id === appId);
    if (!currentApplication) return;
    
    const modalBody = $('#modal-body');
    
    modalBody.html(`
        <div class="application-details">
            <div class="detail-section">
                <h4>Prepare Quote for ${currentApplication.toyName}</h4>
                <div class="detail-item">
                    <span>Customer:</span>
                    <span>${currentApplication.customerName}</span>
                </div>
                <div class="detail-item">
                    <span>Quantity:</span>
                    <span>${currentApplication.quantity}</span>
                </div>
            </div>
            
            <div class="quote-form">
                <h5>Quote Calculation</h5>
                <div class="quote-input-group">
                    <div class="form-group">
                        <label for="base-price">Base Price (per piece)</label>
                        <input type="number" id="base-price" step="0.01" placeholder="0.00">
                    </div>
                    <div class="form-group">
                        <label for="material-cost">Material Cost (per piece)</label>
                        <input type="number" id="material-cost" step="0.01" placeholder="0.00">
                    </div>
                    <div class="form-group">
                        <label for="labor-cost">Labor Cost (per piece)</label>
                        <input type="number" id="labor-cost" step="0.01" placeholder="0.00">
                    </div>
                    <div class="form-group">
                        <label for="additional-cost">Additional Costs</label>
                        <input type="number" id="additional-cost" step="0.01" placeholder="0.00">
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label for="quote-breakdown">Quote Breakdown (Optional)</label>
                    <textarea id="quote-breakdown" placeholder="Provide detailed breakdown of costs..."></textarea>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="production-time-input">Production Time (days)</label>
                        <input type="number" id="production-time-input" min="1" value="14">
                    </div>
                    <div class="form-group">
                        <label for="valid-until-input">Valid Until</label>
                        <input type="date" id="valid-until-input">
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label for="quote-notes">Notes to customer</label>
                    <textarea id="quote-notes" placeholder="Share payment reminders, delivery remarks, etc."></textarea>
                </div>
                
                <div class="quote-summary">
                    <h5>Quote Summary</h5>
                    <div class="summary-item">
                        <span>Total per piece:</span>
                        <span id="per-piece-total">$0.00</span>
                    </div>
                    <div class="summary-item">
                        <span>Quantity:</span>
                        <span>${currentApplication.quantity}</span>
                    </div>
                    <div class="summary-item total">
                        <span>Grand Total:</span>
                        <span id="grand-total">$0.00</span>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    $('#base-price, #material-cost, #labor-cost, #additional-cost').on('input', calculateQuote);
    
    const defaultValidUntil = new Date();
    defaultValidUntil.setDate(defaultValidUntil.getDate() + 30);
    $('#valid-until-input').val(defaultValidUntil.toISOString().split('T')[0]);
    quoteTotals = { perPiece: 0, grandTotal: 0 };
    
    const actionButtons = $('#action-buttons');
    actionButtons.html(`
        <button class="btn btn-primary" onclick="submitQuote()">Submit Quote</button>
        <button class="btn btn-secondary" onclick="viewApplication('${currentApplication.id}')">Cancel</button>
    `);
    
    $('#application-modal').addClass('show');
}

function calculateQuote() {
    const basePrice = parseFloat($('#base-price').val()) || 0;
    const materialCost = parseFloat($('#material-cost').val()) || 0;
    const laborCost = parseFloat($('#labor-cost').val()) || 0;
    const additionalCost = parseFloat($('#additional-cost').val()) || 0;
    
    const perPieceTotal = basePrice + materialCost + laborCost + additionalCost;
    const grandTotal = perPieceTotal * currentApplication.quantity;
    
    quoteTotals.perPiece = perPieceTotal;
    quoteTotals.grandTotal = grandTotal;
    
    $('#per-piece-total').text('$' + perPieceTotal.toFixed(2));
    $('#grand-total').text('$' + grandTotal.toFixed(2));
}

function submitQuote() {
    if (!currentApplication) return;
    
    const quoteAmount = quoteTotals.grandTotal;
    if (quoteAmount <= 0) {
        alert('Please enter valid quote amounts');
        return;
    }
    
    const quoteBreakdown = $('#quote-breakdown').val();
    const quoteNotes = $('#quote-notes').val();
    const productionTime = parseInt($('#production-time-input').val(), 10) || 14;
    const validUntil = $('#valid-until-input').val() || QuotationData.calculateEstimatedCompletion('standard');
    const estimatedCompletion = QuotationData.calculateEstimatedCompletion(currentApplication.urgencyLevel || 'standard');
    
    QuotationData.submitQuote(currentApplication.id, {
        perPiece: quoteTotals.perPiece,
        grandTotal: quoteAmount,
        breakdown: quoteBreakdown,
        quoteNotes,
        productionTime,
        validUntil,
        estimatedCompletion
    }, currentUser.name);
    
    QuotationData.addConversationMessage(currentApplication.id, {
        role: 'sales',
        author: currentUser.name,
        message: `Quotation shared with total $${quoteAmount.toFixed(2)}. ${quoteNotes || 'Let me know if you have any questions.'}`
    });
    
    showNotification('Quote submitted successfully!', 'success');
    closeModal();
    loadApplications();
}

function updateStatus(appId, newStatus) {
    const updatedRequest = QuotationData.updateStatus(appId, newStatus, { notes: `Status updated by ${currentUser.name}` });
    if (updatedRequest) {
        if (newStatus === 'approved') {
            QuotationData.addConversationMessage(appId, {
                role: 'sales',
                author: currentUser.name,
                message: 'Your quotation has been approved. We will proceed to order confirmation.'
            });
        } else if (newStatus === 'rejected') {
            QuotationData.addConversationMessage(appId, {
                role: 'sales',
                author: currentUser.name,
                message: 'The quotation was rejected. Let us know if you would like to revise the requirements.'
            });
        }
        
        showNotification(`Application ${newStatus} successfully!`, 'success');
        closeModal();
        loadApplications();
    }
}

function closeModal() {
    $('#application-modal').removeClass('show');
    currentApplication = null;
}
function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}
function formatDate(dateString) {
    if (!dateString) return 'Not set';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function renderApplicationConversation() {
    if (!currentApplication) return;
    const container = $('#application-conversation');
    if (!container.length) return;
    
    const conversation = currentApplication.conversation || [];
    if (conversation.length === 0) {
        container.html('<div class="empty-state">No messages yet. Start the conversation below.</div>');
        return;
    }
    
    container.html(conversation.map(message => `
        <div class="message ${message.role}">
            <div class="message-meta">
                <span>${message.author}</span>
                <span>${formatDate(message.timestamp)}</span>
            </div>
            <p>${message.message}</p>
        </div>
    `).join(''));
}

function handleSalesReply(event) {
    event.preventDefault();
    if (!currentApplication) return;
    
    const message = $('#sales-reply-message').val().trim();
    if (!message) return;
    
    const updatedConversation = QuotationData.addConversationMessage(currentApplication.id, {
        role: 'sales',
        author: currentUser.name,
        message
    });
    
    currentApplication.conversation = updatedConversation;
    $('#sales-reply-message').val('');
    renderApplicationConversation();
    showNotification('Message sent to customer.', 'success');
}

function showNotification(message, type = 'success') {
    alert(`${type.toUpperCase()}: ${message}`);
}

