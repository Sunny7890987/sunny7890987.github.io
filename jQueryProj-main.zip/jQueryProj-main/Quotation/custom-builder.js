// Custom Toy Builder JavaScript
let currentToyDesign = {};

$(document).ready(function() {
    initializeBuilder();
    
    // Event listeners
    $('#custom-builder-form').on('submit', handleDesignSubmission);
    $('#sketch-upload').on('change', handleSketchUpload);
    
    // Real-time validation
    $('#toy-name, #design-description, #quantity').on('input', validateCurrentStep);
});

function initializeBuilder() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        window.location.href = '../index.html';
        return;
    }
    
    $('#current-user-name').text(currentUser.name);
}

function nextStep(step) {
    if (!validateStep(step - 1)) {
        showNotification('Please complete all required fields', 'error');
        return;
    }
    
    // Update progress tracker
    $('.progress-step').removeClass('step-active step-completed');
    for (let i = 1; i <= step; i++) {
        $(`.progress-step[data-step="${i}"]`).addClass(i === step ? 'step-active' : 'step-completed');
    }
    
    // Show corresponding step
    $('.form-step').removeClass('active');
    $(`.form-step[data-step="${step}"]`).addClass('active');
    
    // If review step, update summary
    if (step === 4) {
        updateReviewSummary();
    }
}

function prevStep(step) {
    $('.progress-step').removeClass('step-active');
    $(`.progress-step[data-step="${step}"]`).addClass('step-active');
    
    $('.form-step').removeClass('active');
    $(`.form-step[data-step="${step}"]`).addClass('active');
}

function validateStep(step) {
    let isValid = true;
    
    switch(step) {
        case 1:
            if (!$('#toy-name').val().trim()) {
                showError('toy-name', 'Toy name is required');
                isValid = false;
            }
            if (!$('#toy-type').val()) {
                showError('toy-type', 'Please select toy type');
                isValid = false;
            }
            if (!$('#quantity').val() || $('#quantity').val() < 1) {
                showError('quantity', 'Valid quantity is required');
                isValid = false;
            }
            break;
            
        case 2:
            if (!$('#design-description').val().trim()) {
                showError('design-description', 'Design description is required');
                isValid = false;
            }
            break;
            
        case 3:
            if (!$('#material-type').val()) {
                showError('material-type', 'Please select primary material');
                isValid = false;
            }
            break;
    }
    
    return isValid;
}

function validateCurrentStep() {
    const currentStep = $('.form-step.active').data('step');
    validateStep(currentStep);
}

function handleSketchUpload(event) {
    const file = event.target.files[0];
    const preview = $('#upload-preview');
    
    if (file) {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.html(`
                    <div class="uploaded-image">
                        <img src="${e.target.result}" alt="Sketch preview">
                        <button type="button" class="btn-remove" onclick="removeUploadedImage()">×</button>
                    </div>
                `);
            };
            reader.readAsDataURL(file);
        } else {
            showNotification('Please upload an image file', 'error');
            event.target.value = '';
        }
    }
}

function removeUploadedImage() {
    $('#sketch-upload').val('');
    $('#upload-preview').empty();
}

function updateReviewSummary() {
    // Basic Information
    $('#review-basic-info').html(`
        <p><strong>Toy Name:</strong> ${$('#toy-name').val()}</p>
        <p><strong>Type:</strong> ${$('#toy-type option:selected').text()}</p>
        <p><strong>Quantity:</strong> ${$('#quantity').val()}</p>
        <p><strong>Age Group:</strong> ${$('#target-age option:selected').text()}</p>
    `);
    
    // Design Information
    const length = $('#length').val() || 'Not specified';
    const width = $('#width').val() || 'Not specified';
    const height = $('#height').val() || 'Not specified';
    
    $('#review-design-info').html(`
        <p><strong>Dimensions:</strong> ${length} × ${width} × ${height} cm</p>
        <p><strong>Design Description:</strong> ${$('#design-description').val()}</p>
    `);
    
    // Materials Information
    const safetyFeatures = $('input[name="safetyFeatures"]:checked').map(function() {
        return $(this).val();
    }).get().join(', ') || 'None';
    
    const specialFeatures = $('input[name="specialFeatures"]:checked').map(function() {
        return $(this).val();
    }).get().join(', ') || 'None';
    
    $('#review-materials-info').html(`
        <p><strong>Primary Material:</strong> ${$('#material-type option:selected').text()}</p>
        <p><strong>Stuffing:</strong> ${$('#stuffing-material option:selected').text()}</p>
        <p><strong>Safety Features:</strong> ${safetyFeatures}</p>
        <p><strong>Special Features:</strong> ${specialFeatures}</p>
        <p><strong>Additional Requirements:</strong> ${$('#additional-requirements').val() || 'None'}</p>
    `);
}

function handleDesignSubmission(event) {
    event.preventDefault();
    
    if (!validateStep(4)) {
        showNotification('Please complete all required information', 'error');
        return;
    }
    
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const formData = new FormData(event.target);
    const formDataObj = Object.fromEntries(formData.entries());
    
    // Create toy design object
    const toyDesign = {
        id: 'TD' + Math.floor(1000 + Math.random() * 9000),
        customerEmail: currentUser.email,
        customerName: currentUser.name,
        ...formDataObj,
        safetyFeatures: $('input[name="safetyFeatures"]:checked').map(function() {
            return $(this).val();
        }).get(),
        specialFeatures: $('input[name="specialFeatures"]:checked').map(function() {
            return $(this).val();
        }).get(),
        sketch: $('#upload-preview img').attr('src') || null,
        createdDate: new Date().toISOString()
    };
    
    // Save to localStorage
    let designs = JSON.parse(localStorage.getItem('toyDesigns') || '[]');
    designs.push(toyDesign);
    localStorage.setItem('toyDesigns', JSON.stringify(designs));
    
    showNotification('Custom toy design saved successfully!', 'success');
    
    // Redirect to quote request
    setTimeout(() => {
        window.location.href = 'quote-request.html?designId=' + toyDesign.id;
    }, 1500);
}

function showError(fieldId, message) {
    $(`#${fieldId}-error`).text(message);
}

function showNotification(message, type = 'success') {
    alert(`${type.toUpperCase()}: ${message}`);
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}