// Quotation System JavaScript - Dashboard with App Management
let quoteRequests = [];
let quotations = [];
let signedInUser = null;


$(document).ready(function() {
    initializeQuotationSystem();
});


function initializeQuotationSystem() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        window.location.href = '../index.html';
        return;
    }
    
    signedInUser = currentUser;
    $('#current-user-name').text(currentUser.name);
    $('#user-role').text('sales');
    
    loadQuoteData();
    loadSalesDashboard();
    
    // Refresh collaboration feed every 30 seconds
    setInterval(renderCollaborationFeed, 30000);
}


function loadQuoteData() {
    // Load from QuotationData module
    quoteRequests = QuotationData.getQuoteRequests() || [];
    quotations = QuotationData.getQuotations() || [];
}


function loadSalesDashboard() {
    updateSalesStatistics();
    loadRecentApplications();
    renderCollaborationFeed();
}


function updateSalesStatistics() {
    const today = new Date().toISOString().split('T')[0];
    

    const pending = quoteRequests.filter(q => q.status === 'pending').length;
    const quotesToday = quoteRequests.filter(q => 
        new Date(q.submittedDate).toISOString().split('T')[0] === today
    ).length;
    const newRequests = quoteRequests.filter(q => q.status === 'pending').length;
    const accepted = quoteRequests.filter(q => q.status === 'approved').length;
    

    $('#pending-quotes').text(pending);
    $('#quotes-today').text(quotesToday);
    $('#new-requests-count').text(newRequests);
    $('#accepted-quotes-count').text(accepted);
}


function loadRecentApplications() {
    const recent = [...quoteRequests]
        .sort((a, b) => new Date(b.submittedDate) - new Date(a.submittedDate))
        .slice(0, 5);
    
    displayRecentApplications(recent);
}


function displayRecentApplications(requests) {
    const container = $('#recent-applications');
    
    if (requests.length === 0) {
        container.html('<div class="empty-state">No recent applications</div>');
        return;
    }
    
    const html = requests.map(request => `
        <div class="application-item" onclick="viewApplicationFromDashboard('${request.id}')" style="cursor: pointer;">
            <div class="app-info">
                <strong>${request.toyName}</strong>
                <span class="status-badge status-${request.status}">${request.status}</span>
            </div>
            <div class="app-details">
                ${request.customerName} • ${request.quantity} pcs • ${formatDate(request.submittedDate)}
            </div>
        </div>
    `).join('');
    
    container.html(html);
}


function renderCollaborationFeed() {
    const feed = $('#collaboration-feed');
    
    // Get all applications with conversations
    const applicationsWithMessages = quoteRequests.filter(app => 
        app.conversation && app.conversation.length > 0
    );
    
    if (applicationsWithMessages.length === 0) {
        feed.html(`
            <div class="empty-state">
                <p>No recent messages</p>
                <small>Customer messages will appear here when they reply to quotes</small>
            </div>
        `);
        return;
    }
    
    // Collect all messages from all applications
    let allMessages = [];
    
    applicationsWithMessages.forEach(app => {
        app.conversation.forEach(message => {
            allMessages.push({
                ...message,
                applicationId: app.id,
                toyName: app.toyName,
                customerName: app.customerName
            });
        });
    });
    
    // Sort by timestamp (newest first)
    allMessages.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Take only the 6 most recent messages
    const recentMessages = allMessages.slice(0, 6);
    
    const html = recentMessages.map(message => `
        <div class="message ${message.role} ${message.role === 'customer' ? 'customer-message' : 'sales-message'}" 
             onclick="viewApplicationFromDashboard('${message.applicationId}')" 
             style="cursor: pointer; border-left: 4px solid ${message.role === 'customer' ? '#e74c3c' : '#3498db'};">
            <div class="message-header">
                <div class="message-meta">
                    <strong class="message-author">${message.author}</strong>
                    <span class="message-application">${message.toyName} • ${message.applicationId}</span>
                </div>
                <span class="message-time">${formatMessageTime(message.timestamp)}</span>
            </div>
            <p class="message-content">${message.message}</p>
            ${message.role === 'customer' ? '<div class="customer-badge">Customer</div>' : ''}
        </div>
    `).join('');
    
    feed.html(html);
    
    // Add some basic styling for the messages
    addCollaborationStyles();
}

/**
 * 添加协作中心样式
 */
function addCollaborationStyles() {
    if (!$('#collaboration-styles').length) {
        const styles = `
            <style id="collaboration-styles">
                .customer-message {
                    background: #fff5f5;
                    border: 1px solid #fed7d7;
                }
                .sales-message {
                    background: #f0f9ff;
                    border: 1px solid #bee3f8;
                }
                .message {
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 0.75rem;
                    transition: all 0.2s ease;
                }
                .message:hover {
                    transform: translateY(-1px);
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }
                .message-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    margin-bottom: 0.5rem;
                }
                .message-meta {
                    display: flex;
                    flex-direction: column;
                }
                .message-author {
                    color: #2d3748;
                    font-size: 0.9rem;
                }
                .message-application {
                    color: #718096;
                    font-size: 0.8rem;
                    margin-top: 0.1rem;
                }
                .message-time {
                    color: #a0aec0;
                    font-size: 0.8rem;
                    white-space: nowrap;
                }
                .message-content {
                    color: #4a5568;
                    margin: 0;
                    line-height: 1.4;
                }
                .customer-badge {
                    display: inline-block;
                    background: #e74c3c;
                    color: white;
                    padding: 0.2rem 0.5rem;
                    border-radius: 12px;
                    font-size: 0.7rem;
                    margin-top: 0.5rem;
                }
                .empty-state {
                    text-align: center;
                    padding: 2rem;
                    color: #718096;
                }
                .empty-state p {
                    margin-bottom: 0.5rem;
                }
                .empty-state small {
                    font-size: 0.8rem;
                }
            </style>
        `;
        $('head').append(styles);
    }
}


function viewApplicationFromDashboard(applicationId) {
    console.log('Navigating to application:', applicationId);
    localStorage.setItem('lastViewedApplication', applicationId);
    localStorage.setItem('autoOpenApplication', 'true');
    window.location.href = `app-management.html?applicationId=${applicationId}&source=dashboard`;
}
function refreshCollaborationFeed() {
    loadQuoteData(); 
    renderCollaborationFeed();
    showNotification('Collaboration feed refreshed', 'success');
}


function updateCollaborationStats() {
    const applicationsWithMessages = quoteRequests.filter(app => 
        app.conversation && app.conversation.length > 0
    );
    
    let unreadCount = 0;
    applicationsWithMessages.forEach(app => {

        const recentCustomerMessages = app.conversation.filter(msg => 
            msg.role === 'customer' && 
            new Date(msg.timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)
        );
        unreadCount += recentCustomerMessages.length;
    });
    
    $('#active-conversations').text(applicationsWithMessages.length);
    $('#unread-messages').text(unreadCount);
}

function showConfirmation(title, message, confirmCallback) {
    $('#confirmation-title').text(title);
    $('#confirmation-message').text(message);
    $('#confirm-action-btn').off('click').on('click', function() {
        confirmCallback();
        closeModal();
    });
    $('#confirmation-modal').removeClass('hidden');
}


function closeModal() {
    $('.modal').addClass('hidden');
}


function formatDate(dateString) {
    if (!dateString) return 'Not set';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric',
        month: 'short', 
        day: 'numeric'
    });
}


function formatMessageTime(timestamp) {
    if (!timestamp) return '';
    
    const messageTime = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now - messageTime) / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);
    
    if (diffInMinutes < 1) {
        return 'Just now';
    } else if (diffInMinutes < 60) {
        return `${diffInMinutes}m ago`;
    } else if (diffInHours < 24) {
        return `${diffInHours}h ago`;
    } else if (diffInDays < 7) {
        return `${diffInDays}d ago`;
    } else {
        return messageTime.toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric'
        });
    }
}


function showNotification(message, type = 'success') {
    alert(`${type.toUpperCase()}: ${message}`);
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}

function navigateTo(page) {
    window.location.href = page;
}