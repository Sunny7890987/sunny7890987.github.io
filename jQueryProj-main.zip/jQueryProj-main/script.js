// Demo users (kept for compatibility)
const demoUsers = {
  'customer@example.com': { password: 'password123', name: 'John Doe', type: 'customer', phone: '12345678' },
  'sales@example.com': { password: 'password123', name: 'Jane Smith', type: 'sales', phone: '87654321', staffNumber: 'S12345' }
};

let currentUser = null;

function navigateToQuotationSystem(section = null) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        showNotification('please login', 'error');
        window.location.href = 'index.html';
        return;
    }
    
    if (currentUser.type === 'customer') {
        window.location.href = 'Quotation/custom-builder.html';
    } else {
        window.location.href = 'Quotation/index.html';
    }
}
// Helper: get registered users from localStorage
function getRegisteredUsers() {
  try {
    return JSON.parse(localStorage.getItem('registeredUsers') || '{}');
  } catch(e) {
    return {};
  }
}
function setRegisteredUsers(obj) {
  localStorage.setItem('registeredUsers', JSON.stringify(obj));
}

// DOM ready
document.addEventListener('DOMContentLoaded', () => {
  // wire up forms if on index.html
  if (document.getElementById('login-form')) {
    document.getElementById('login-form').addEventListener('submit', handleLogin);
  }
  if (document.getElementById('register-form')) {
    document.getElementById('register-form').addEventListener('submit', handleRegistration);
    document.getElementById('register-type').addEventListener('change', toggleRegistrationFields);
  }

  // Update nav if logged in
  checkLoginStatus();

  // Show home section by default if user is not logged in
  if (!currentUser) {
    showSection('home');
  }

  // set up simple navigation helpers
  window.showHome = () => {
    showSection('home');
  };
  window.showLogin = () => {
    showSection('login-section');
  };
  window.showRegister = () => {
    showSection('register-section');
    toggleRegistrationFields();
  };

  // 添加全局导航函数
  window.navigateToQuotationSystem = (section = null) => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
      showLogin();
      return;
    }
    
    if (currentUser.type === 'customer') {
      window.location.href = 'Quotation/custom-builder.html';
    } else {
      window.location.href = 'Quotation/app-management.html';
    }
  };
});

function toggleRegistrationFields() {
  const type = document.getElementById('register-type').value;
  const salesField = document.querySelector('.sales-field');
  
  if (salesField) {
    if (type === 'sales') {
      salesField.classList.remove('hidden');
    } else {
      salesField.classList.add('hidden');
    }
  }
}

// UI helpers for index.html
function showSection(id) {
  // Hide all sections first
  const sections = document.querySelectorAll('.section');
  sections.forEach(s => s.classList.add('hidden'));
  
  // Show the requested section
  const el = document.getElementById(id);
  if (el) el.classList.remove('hidden');
  
  updateNavActive(id);
}
function updateNavActive(id) {
  // Reset all nav items
  const loginNav = document.getElementById('login-nav');
  const registerNav = document.getElementById('register-nav');
  const navWelcome = document.getElementById('nav-welcome');
  const navLogout = document.getElementById('nav-logout');
  
  if (loginNav && registerNav) {
    // Show login/register buttons only if user is not logged in
    if (!currentUser) {
      loginNav.classList.remove('hidden');
      registerNav.classList.remove('hidden');
      if (navWelcome) navWelcome.classList.add('hidden');
      if (navLogout) navLogout.classList.add('hidden');
    } else {
      // User is logged in, show welcome and logout
      loginNav.classList.add('hidden');
      registerNav.classList.add('hidden');
      if (navWelcome) navWelcome.classList.remove('hidden');
      if (navLogout) navLogout.classList.remove('hidden');
    }
  }
}

// Registration -> save to localStorage registeredUsers
function handleRegistration(e) {
  e.preventDefault();
  clearRegisterErrors();
  const type = document.getElementById('register-type').value;
  const name = document.getElementById('register-name').value.trim();
  const email = document.getElementById('register-email').value.trim().toLowerCase();
  const phone = document.getElementById('register-phone').value.trim();
  const staffNumber = document.getElementById('staff-number') ? document.getElementById('staff-number').value.trim() : '';
  const password = document.getElementById('register-password').value;
  const confirm = document.getElementById('register-confirm-password').value;
  const terms = document.getElementById('terms').checked;

  if (!name) return showRegisterError('register-name-error','Please enter your name');
  if (!validateEmail(email)) return showRegisterError('register-email-error','Enter a valid email');
  if (!phone) return showRegisterError('register-phone-error','Enter your phone');
  if (!password || password.length < 6) return showRegisterError('register-password-error','Password must be at least 6 characters');
  if (password !== confirm) return showRegisterError('register-confirm-password-error','Passwords do not match');
  if (!terms) return showRegisterError('terms-error','You must accept the terms');

  // Check demoUsers first
  if (demoUsers[email]) {
    return showRegisterError('register-email-error','This email is reserved for demo users. Please use a different email.');
  }
  const registered = getRegisteredUsers();
  if (registered[email]) {
    return showRegisterError('register-email-error','This email is already registered. Try logging in.');
  }

  // Save
  registered[email] = { password, name, type, phone, staffNumber };
  setRegisteredUsers(registered);
  showNotification('Registration saved! Please login.', 'success');
  // switch to login
  setTimeout(() => { showLogin(); }, 700);
}

function showRegisterError(id, msg) {
  const el = document.getElementById(id);
  if (el) el.textContent = msg;
}

function clearRegisterErrors() {
  ['register-name-error','register-email-error','register-phone-error','register-password-error','register-confirm-password-error','terms-error','staff-number-error'].forEach(id => {
    const el = document.getElementById(id); if (el) el.textContent='';
  });
}

// Login: checks demoUsers then registeredUsers
function handleLogin(e) {
  e.preventDefault();
  clearLoginErrors();
  const email = (document.getElementById('login-email').value || '').trim().toLowerCase();
  const password = document.getElementById('login-password').value || '';
  const type = document.getElementById('login-type').value || 'customer';
  if (!validateEmail(email)) return showLoginError('login-email-error','Enter a valid email');
  if (!password) return showLoginError('login-password-error','Enter your password');

  // check demoUsers
  if (demoUsers[email]) {
    if (demoUsers[email].password === password) {
      if (demoUsers[email].type !== type) return showLoginError('login-password-error',`This demo account is a ${demoUsers[email].type}. Choose the correct role.`);
      currentUser = { email, ...demoUsers[email] };
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      redirectBasedOnRole(currentUser.type);
      return;
    } else {
      return showLoginError('login-password-error','Incorrect password for demo user');
    }
  }

  // check registered users
  const registered = getRegisteredUsers();
  if (registered[email]) {
    if (registered[email].password === password) {
      if (registered[email].type !== type) return showLoginError('login-password-error',`This account is registered as ${registered[email].type}. Choose correct role.`);
      currentUser = { email, ...registered[email] };
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      redirectBasedOnRole(currentUser.type);
      return;
    } else {
      return showLoginError('login-password-error','Incorrect password');
    }
  }

  return showLoginError('login-email-error','No account found with this email address.');
}

function showLoginError(id,msg) {
  const el = document.getElementById(id);
  if (el) el.textContent = msg;
}
function clearLoginErrors() {
  ['login-email-error','login-password-error'].forEach(id => { const el = document.getElementById(id); if (el) el.textContent=''; });
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function redirectBasedOnRole(role) {
  showNotification('Login successful! Redirecting...', 'success');
  setTimeout(() => {
    if (role === 'customer') window.location.href = 'customer.html';
    else window.location.href = './Quotation/quotation-system.html';
  }, 700);
}

// check login status and update nav
function checkLoginStatus() {
    try {
        const saved = JSON.parse(localStorage.getItem('currentUser') || 'null');
        if (saved) {
            currentUser = saved;
            updateUserInfoOnAllPages();
        } else {
            if (!window.location.pathname.endsWith('index.html')) {
                window.location.href = 'index.html';
            }
        }
    } catch(e) {
        console.error('Error:', e);
    }
}

function updateUserInfoOnAllPages() {
    const userElements = document.querySelectorAll('#current-user-name, #nav-user-name, #sales-name, #cust-name');
    userElements.forEach(el => {
        if (el && currentUser) el.textContent = currentUser.name;
    });
}

// logout
function logout() {
  localStorage.removeItem('currentUser');
  currentUser = null;
  // redirect to landing
  window.location.href = 'index.html';
}

// notification
function showNotification(message, type='success') {
  const n = document.getElementById('notification') || createFloatingNotification();
  n.className = 'notification ' + (type === 'error' ? 'error' : 'success');
  n.textContent = message;
  n.classList.add('show');
  setTimeout(()=>{ n.classList.remove('show'); }, 2500);
}
function createFloatingNotification() {
  const n = document.createElement('div');
  n.id = 'notification';
  n.className = 'notification';
  n.setAttribute('role','status');
  document.body.appendChild(n);
  return n;
}

// sales stats loader (reads localStorage quoteRequests/quotations if present)
function loadSalesStats() {
  const quoteRequests = JSON.parse(localStorage.getItem('quoteRequests') || '[]');
  const quotations = JSON.parse(localStorage.getItem('quotations') || '[]');
  const pending = quoteRequests.filter(q => q.status === 'pending').length;
  const today = new Date().toISOString().split('T')[0];
  const quotesToday = quoteRequests.filter(q => q.submittedDate === today).length;
  const accepted = quotations.filter(q => q.status === 'accepted').length;
  const convRate = quotations.length ? Math.round(accepted / quotations.length * 100) + '%' : '0%';
  const elPending = document.getElementById('pending-quotes'); if (elPending) elPending.textContent = pending;
  const elToday = document.getElementById('quotes-today'); if (elToday) elToday.textContent = quotesToday;
  const elConv = document.getElementById('conversion-rate'); if (elConv) elConv.textContent = convRate;
}

function navigateToPage(page) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        showNotification('请先登录', 'error');
        return;
    }
    
    if (page.includes('management') && currentUser.type !== 'sales') {
        showNotification('无权访问此页面', 'error');
        return;
    }
    
    window.location.href = page;
}


const DataManager = {
    getQuoteRequests: function() {
        try {
            return JSON.parse(localStorage.getItem('quoteRequests') || '[]');
        } catch(e) {
            return [];
        }
    },
    
    saveQuoteRequests: function(requests) {
        localStorage.setItem('quoteRequests', JSON.stringify(requests));
    },
    
    getQuotations: function() {
        try {
            return JSON.parse(localStorage.getItem('quotations') || '[]');
        } catch(e) {
            return [];
        }
    },
    
    saveQuotations: function(quotations) {
        localStorage.setItem('quotations', JSON.stringify(quotations));
    },
    
    getToyDesigns: function() {
        try {
            return JSON.parse(localStorage.getItem('toyDesigns') || '[]');
        } catch(e) {
            return [];
        }
    },
    
    saveToyDesigns: function(designs) {
        localStorage.setItem('toyDesigns', JSON.stringify(designs));
    }
};
function navigateToQuoteTracking() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        showNotification('please login first', 'error');
        return;
    }
    
    if (currentUser.type !== 'customer') {
        showNotification('only for customer', 'error');
        return;
    }
    
    window.location.href = 'Quotation/quote-tracking.html';
}
// Expose some functions globally for simple inline handlers
window.showNotification = showNotification;
window.navigateToQuotationSystem = navigateToQuotationSystem;
window.navigateToQuoteTracking = navigateToQuoteTracking;