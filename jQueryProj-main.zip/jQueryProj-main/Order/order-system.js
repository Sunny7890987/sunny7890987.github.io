const STORAGE_WISHLIST = 'wishlist';
const STORAGE_CART = 'cart';
const STORAGE_ORDERS = 'orders';

// In-memory state
let toys = [];
let wishlist = [];
let cart = [];

// Demo toy catalogue
const demoToys = [
  {
    id: 1,
    name: "Educational Robot Kit",
    category: "educational",
    price: 89.99,
    ageRange: "7-12",
    image: "🤖",
    rating: 4.5
  },
  {
    id: 2,
    name: "Outdoor Adventure Set",
    category: "outdoor",
    price: 39.99,
    ageRange: "4-8",
    image: "🧭",
    rating: 4.2
  },
  {
    id: 3,
    name: "Creative Art Studio",
    category: "creative",
    price: 49.99,
    ageRange: "5-10",
    image: "🎨",
    rating: 4.7
  },
  {
    id: 4,
    name: "Interactive Storybook Plush",
    category: "electronic",
    price: 59.99,
    ageRange: "3-7",
    image: "📖",
    rating: 4.4
  },
  {
    id: 5,
    name: "STEM Building Blocks",
    category: "educational",
    price: 29.99,
    ageRange: "6-12",
    image: "🧱",
    rating: 4.6
  },
  {
    id: 6,
    name: "Science Experiment Lab",
    category: "educational",
    price: 79.99,
    ageRange: "7-12",
    image: "🔬",
    rating: 4.8
  }
];

// --- Core helpers ---

function getCurrentUser() {
  const raw = localStorage.getItem('currentUser');
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return null;
  }
  $('#current-user-name').text(user.name || '');
  return user;
}

function loadState() {
  try {
    wishlist = JSON.parse(localStorage.getItem(STORAGE_WISHLIST)) || [];
  } catch (e) {
    wishlist = [];
  }
  try {
    cart = JSON.parse(localStorage.getItem(STORAGE_CART)) || [];
  } catch (e) {
    cart = [];
  }
}

function saveWishlist() {
  localStorage.setItem(STORAGE_WISHLIST, JSON.stringify(wishlist));
  updateWishlistCount();
}

function saveCart() {
  localStorage.setItem(STORAGE_CART, JSON.stringify(cart));
  updateCartCount();
}

function updateWishlistCount() {
  const count = wishlist.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.wishlist-count').text(count);
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.cart-count').text(count);
}

function showNotification(message, type = 'info') {
  const notification = $('#notification');
  
  // Fallback to console if the toast container isn't present
  if (!notification.length) {
    const prefix = type ? `[${type.toUpperCase()}] ` : '';
    if (type === 'error') {
      console.error(prefix + message);
    } else {
      console.log(prefix + message);
    }
    return;
  }
  
  // Remove previous type classes
  notification.removeClass('success error info');
  
  if (type) {
    notification.addClass(type);
  }
  
  notification.text(message);
  notification.addClass('show');
  
  // Clear previous timeout if any
  if (window._notificationTimeout) {
    clearTimeout(window._notificationTimeout);
  }
  
  window._notificationTimeout = setTimeout(() => {
    notification.removeClass('show');
  }, 3000);
}

// --- Toy browsing ---

function loadToys() {
  toys = demoToys.slice();
  displayToys(toys);
}

function displayToys(toysToShow) {
  const grid = $('#toys-grid');
  if (!grid.length) return;
  
  grid.empty();
  
  if (!toysToShow.length) {
    grid.html('<div class="empty-state"><p>No toys found matching your criteria.</p></div>');
    return;
  }
  
  toysToShow.forEach(toy => {
    const isInWishlist = wishlist.some(item => item.id === toy.id);
    
    const wishlistButton = isInWishlist
    ? `<button class="btn btn-outline" onclick="removeFromWishlist(${toy.id}); event.stopPropagation();">Remove from Wishlist</button>`
    : `<button class="btn btn-primary" onclick="addToWishlist(${toy.id}); event.stopPropagation();">Add to Wishlist</button>`;
    
    const cardHtml = `
    <div class="toy-card" onclick="showToyDetails(${toy.id})">
    <div class="toy-image">
    ${toy.image}
    </div>
    <div class="toy-info">
    <div class="toy-name">${toy.name}</div>
    <div class="toy-category">${toy.category} • ${toy.ageRange} years</div>
    <div class="toy-price">$${toy.price.toFixed(2)}</div>
    <div class="toy-rating">⭐ ${toy.rating.toFixed(1)}</div>
    <div class="toy-actions">
    ${wishlistButton}
    <button class="btn btn-secondary" onclick="addToCart(${toy.id}); event.stopPropagation();">Quick Add</button>
    </div>
    </div>
    </div>
    `;
    grid.append(cardHtml);
  });
}

function parseAgeRange(rangeStr) {
  if (!rangeStr) return null;
  const parts = rangeStr.split('-');
  const min = parseInt(parts[0], 10);

  let max;
  if (parts.length === 1 || (parts[1] && parts[1].includes('+'))) {
    max = Infinity;
  } else {
    max = parseInt(parts[1], 10);
  }
  
  if (Number.isNaN(min)) return null;
  if (Number.isNaN(max)) max = Infinity;
  
  return { min, max };
}

// to-do: add a sort func
// done :>
let currentSort = '';
function applyToyFilters() {
  if (!toys.length) return;
  
  const searchTerm = ($('#toy-search').val() || '').toLowerCase().trim();
  const category = $('#category-filter').val();
  const priceRange = $('#price-filter').val();
  const ageRange = $('#age-filter').val();

  let filtered = toys.slice();

  if (searchTerm) {
    filtered = filtered.filter(toy =>
      toy.name.toLowerCase().includes(searchTerm) || toy.category.toLowerCase().includes(searchTerm)
    );
  }

  if (category) {
    filtered = filtered.filter(toy => toy.category === category);
  }

  if (priceRange) {
    filtered = filtered.filter(toy => {
      if (priceRange === '0-50') return toy.price >= 0 && toy.price <= 50;
      if (priceRange === '51-100') return toy.price > 50 && toy.price <= 100;
      if (priceRange === '101-200') return toy.price > 100 && toy.price <= 200;
      if (priceRange === '201+') return toy.price > 200;
      return true;
    });
  }

  if (ageRange) {
    const selected = parseAgeRange(ageRange);
    if (selected) {
      filtered = filtered.filter(toy => {
        const toyRange = parseAgeRange(toy.ageRange);
        return toyRange.min <= selected.max && toyRange.max >= selected.min;
      });
    }
  }

  // sort function
  if (currentSort === 'name') {
    filtered.sort((a, b) => a.name.localeCompare(b.name));
  } else if (currentSort === 'price-asc') {
    filtered.sort((a, b) => Number(a.price) - Number(b.price));
  } else if (currentSort === 'price-desc') {
    filtered.sort((a, b) => Number(b.price) - Number(a.price));
  } else if (currentSort === 'age') {
    filtered.sort((a, b) => {
      const ra = parseAgeRange(a.ageRange) || { min: Infinity, max: Infinity };
      const rb = parseAgeRange(b.ageRange) || { min: Infinity, max: Infinity };
      if (ra.min !== rb.min) return ra.min - rb.min;
      return ra.max - rb.max;
    });
  }

  displayToys(filtered);
}

function searchToys() {
  applyToyFilters();
}

function initSortControls() {
  const $menu = $('#sort-menu');
  const $toggle = $('#sort-toggle');

  if (!$menu.length || !$toggle.length) return;

  const labels = {
    '': '⇅ Sort: Default',
    'name': '⇅ Sort: Name',
    'price-asc': '⇅ Sort: Price (Low-High)',
    'price-desc': '⇅ Sort: Price (High-Low)',
    'age': '⇅ Sort: Age range'
  };

  $toggle.on('click', function () {
    $menu.toggleClass('show');
  });

  $menu.on('click', '.sort-option', function () {
    const value = $(this).data('sort') || '';
    currentSort = value;
    $toggle.text(labels[value] || '⇅ Sort');
    $menu.removeClass('show');
    applyToyFilters();
  });

  $(document).on('click', function (e) {
    if (!$(e.target).closest('.sort-wrapper').length) {
      $menu.removeClass('show');
    }
  });
}


function searchToys() {
  applyToyFilters();
}

function filterToys() {
  applyToyFilters();
}

// --- Wishlist operations ---

function addToWishlist(toyId) {
  const toy = toys.find(t => t.id === toyId);
  if (!toy) return;

  const existing = wishlist.find(item => item.id === toyId);
  if (existing) {
    showNotification('This toy is already in your wishlist', 'info');
    return;
  }

  wishlist.push({
    id: toy.id,
    name: toy.name,
    category: toy.category,
    price: toy.price,
    ageRange: toy.ageRange,
    description: toy.description,
    image: toy.image,
    quantity: 1,
    addedDate: new Date().toISOString()
  });

  saveWishlist();
  applyToyFilters(); // refresh cards so button changes to “Remove from Wishlist”
  showNotification('Added to wishlist', 'success');
}

function removeFromWishlist(toyId) {
  wishlist = wishlist.filter(item => item.id !== toyId);
  saveWishlist();
  applyToyFilters(); // refresh cards so button changes back to “Add to Wishlist”
  showNotification('Removed from wishlist', 'success');
}


// --- Cart operations (storage only; UI is on cart/checkout pages) ---

function addToCart(toyId) {
  const toy = toys.find(t => t.id === toyId);
  if (!toy) return;

  const existing = cart.find(item => item.id === toyId);
  if (existing) {
    existing.quantity = (existing.quantity || 1) + 1;
  } else {
    cart.push({
      id: toy.id,
      name: toy.name,
      category: toy.category,
      price: toy.price,
      ageRange: toy.ageRange,
      description: toy.description,
      image: toy.image,
      quantity: 1,
      addedDate: new Date().toISOString()
    });
  }

  saveCart();
  showNotification('Added to cart', 'success');
}

// --- Navigation helpers (for old inline handlers) ---

function showSection(sectionId) {
  if (sectionId === 'browse-toys') {
    window.location.href = 'order-system.html';
  } else if (sectionId === 'wishlist-section') {
    window.location.href = 'wishlist.html';
  } else if (sectionId === 'order-management') {
    window.location.href = 'cart.html';
  } else if (sectionId === 'checkout-section') {
    window.location.href = 'checkout.html';
  } else if (sectionId === 'order-tracking') {
    window.location.href = 'orders.html';
  }
}

// --- logout helper ---

function logout() {
  const ok = window.confirm('Are you sure you want to log out?');
  if (!ok) return;

  // Back to login / landing
  window.location.href = '../index.html';
}

// --- Initialisation ---

$(document).ready(function () {
  const user = requireAuth();
  if (!user) return;

  loadState();
  updateWishlistCount();
  updateCartCount();
  loadToys();
  initSortControls();
});

// Expose functions for inline handlers
window.searchToys = searchToys;
window.filterToys = filterToys;
window.addToWishlist = addToWishlist;
window.removeFromWishlist = removeFromWishlist;
window.addToCart = addToCart;
window.showSection = showSection;
