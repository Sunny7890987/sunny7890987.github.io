const STORAGE_WISHLIST = 'wishlist';
const STORAGE_CART = 'cart';
const STORAGE_ORDERS = 'orders';

let wishlist = [];
let cart = [];
let orders = [];

function getCurrentUser() {
  const raw = localStorage.getItem('currentUser');
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return null;
  }
  $('#current-user-name').text(user.name || '');
  return user;
}

function loadState() {
  try {
    wishlist = JSON.parse(localStorage.getItem(STORAGE_WISHLIST)) || [];
  } catch (e) {
    wishlist = [];
  }
  try {
    cart = JSON.parse(localStorage.getItem(STORAGE_CART)) || [];
  } catch (e) {
    cart = [];
  }
  try {
    orders = JSON.parse(localStorage.getItem(STORAGE_ORDERS)) || [];
  } catch (e) {
    orders = [];
  }
}

function updateWishlistCount() {
  const count = wishlist.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.wishlist-count').text(count);
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.cart-count').text(count);
}

function showNotification(message, type = 'info') {
  const prefix = type ? `[${type.toUpperCase()}] ` : '';

  if (type === 'error') {
    console.error(prefix + message);
  } else {
    console.log(prefix + message);
  }
}

// --- Orders rendering ---

function loadOrders() {
  const list = $('#orders-list');
  const emptyState = $('#no-orders');

  if (!list.length) return;

  list.empty();

  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }

  const userOrders = orders.filter(o => o.customerEmail === user.email);

  // sort reverse chronologically
  userOrders.sort((a, b) => {
    const ta = a.orderDate ? new Date(a.orderDate).getTime() : 0;
    const tb = b.orderDate ? new Date(b.orderDate).getTime() : 0;
    return tb - ta;
  });

  if (!userOrders.length) {
    list.hide();
    emptyState.show();
    return;
  }


  emptyState.hide();
  list.show();

  userOrders.forEach(order => {
    const itemCount = (order.items || []).reduce(
      (sum, item) => sum + (item.quantity || 1),
      0
    );

    const html = `
      <div class="order-card">
        <div class="order-header">
          <span class="order-id">Order #${order.id}</span>
          <span class="order-status status-${order.status || 'pending'}">
            ${(order.status || 'pending').charAt(0).toUpperCase() + (order.status || 'pending').slice(1)}
          </span>
        </div>
        <div class="order-body">
          <div>Date: ${order.orderDate || ''}</div>
          <div>Items: ${itemCount}</div>
          <div>Total: $${Number(order.total || 0).toFixed(2)}</div>
          <div>Estimated delivery: ${order.estimatedDelivery || 'TBC'}</div>
        </div>
        <div class="order-actions">
          <button class="btn btn-outline" onclick="viewOrderDetails('${order.id}')">
            View details
          </button>
        </div>
      </div>
    `;
    list.append(html);
  });
}

function viewOrderDetails(orderId) {
  const modal = $('#order-details-modal');
  const body = $('#order-details-body');

  if (!modal.length || !body.length) return;

  const order = orders.find(o => String(o.id) === String(orderId));
  if (!order) {
    showNotification('Order not found', 'error');
    return;
  }

  const items = order.items || [];
  const itemsHtml = items.map(item => {
    const qty = item.quantity || 1;
    const price = Number(item.price || 0);
    return `
      <div class="order-item">
        <div>
          <strong>${item.name}</strong>
          <div>Quantity: ${qty}</div>
        </div>
        <div>
          $${price.toFixed(2)}
        </div>
      </div>
    `;
  }).join('');

  body.html(`
    <p><strong>Order ID:</strong> ${order.id}</p>
    <p><strong>Date:</strong> ${order.orderDate || ''}</p>
    <p><strong>Status:</strong> ${(order.status || 'pending').charAt(0).toUpperCase() + (order.status || 'pending').slice(1)}</p>
    <p><strong>Total:</strong> $${Number(order.total || 0).toFixed(2)}</p>
    <p><strong>Estimated delivery:</strong> ${order.estimatedDelivery || 'TBC'}</p>
    <hr>
    <p><strong>Shipping address:</strong></p>
    <p>${order.shippingAddress || ''}</p>
    <p><strong>Shipping method:</strong> ${order.shippingMethod || ''}</p>
    <p><strong>Payment method:</strong> ${order.paymentMethod || ''}</p>
    <hr>
    <div class="order-items">
      ${itemsHtml || '<p>No items in this order.</p>'}
    </div>
  `);

  modal.removeClass('hidden');
}

function closeModal() {
  $('.modal').addClass('hidden');
}


// Simple navigation helper for old inline handler
function showSection(sectionId) {
  if (sectionId === 'browse-toys') {
    window.location.href = 'order-system.html';
  }
}

// --- logout helper ---

function logout() {
  const ok = window.confirm('Are you sure you want to log out?');
  if (!ok) return;

  // Back to login / landing
  window.location.href = '../index.html';
}

// --- Initialisation ---

$(document).ready(function () {
  const user = requireAuth();
  if (!user) return;

  loadState();
  updateWishlistCount();
  updateCartCount();
  loadOrders();
});

// Expose for inline handlers
window.showSection = showSection;
window.loadOrders = loadOrders;
window.viewOrderDetails = viewOrderDetails;
window.closeModal = closeModal;