const STORAGE_WISHLIST = 'wishlist';
const STORAGE_CART = 'cart';
const STORAGE_ORDERS = 'orders';

let wishlist = [];
let cart = [];
let orders = [
  // demo orders
  {
    id: 1001,
    customerEmail: "customer@example.com",
    items: [
        { toyId: 1, name: "Educational Robot Kit", price: 89.99, quantity: 1 },
        { toyId: 5, name: "Building Blocks Set", price: 39.99, quantity: 2 }
    ],
    total: 169.97,
    status: "delivered",
    orderDate: "2025-01-15",
    estimatedDelivery: "2025-01-20",
    shippingAddress: "123 Main St, Hong Kong",
    shippingMethod: "standard"
  },
  {
      id: 1002,
      customerEmail: "customer@example.com",
      items: [
          { toyId: 3, name: "Creative Art Station", price: 129.99, quantity: 1 }
      ],
      total: 129.99,
      status: "processing",
      orderDate: "2025-03-10",
      estimatedDelivery: "2025-03-17",
      shippingAddress: "123 Main St, Hong Kong",
      shippingMethod: "express"
  }
];

function getCurrentUser() {
  const raw = localStorage.getItem('currentUser');
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return null;
  }
  $('#current-user-name').text(user.name || '');
  return user;
}

function loadState() {
  try {
    wishlist = JSON.parse(localStorage.getItem(STORAGE_WISHLIST)) || [];
  } catch (e) {
    wishlist = [];
  }
  try {
    cart = JSON.parse(localStorage.getItem(STORAGE_CART)) || [];
  } catch (e) {
    cart = [];
  }
  try {
    orders = JSON.parse(localStorage.getItem(STORAGE_ORDERS)) || [];
  } catch (e) {
    orders = [];
  }
}

function saveCart() {
  localStorage.setItem(STORAGE_CART, JSON.stringify(cart));
  updateCartCount();
}

function saveOrders() {
  localStorage.setItem(STORAGE_ORDERS, JSON.stringify(orders));
}

function updateWishlistCount() {
  const count = wishlist.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.wishlist-count').text(count);
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.cart-count').text(count);
}

function showNotification(message, type = 'info') {
  const prefix = type ? `[${type.toUpperCase()}] ` : '';

  if (type === 'error') {
    console.error(prefix + message);
  } else {
    console.log(prefix + message);
  }
}

function calculateShippingCost() {
  const method = $('#shipping-method').val();
  switch (method) {
    case 'express':
      return 15;
    case 'next-day':
      return 25;
    default:
      return 0;
  }
}

function calculateEstimatedDelivery(shippingMethod) {
  const today = new Date();
  let days;

  switch (shippingMethod) {
    case 'next-day':
      days = 1;
      break;
    case 'express':
      days = 3;
      break;
    default:
      days = 7;
  }

  const delivery = new Date(today);
  delivery.setDate(today.getDate() + days);
  return delivery.toISOString().split('T')[0];
}

function generateOrderId() {
  return Math.floor(1000 + Math.random() * 9000);
}

function loadCheckoutSummary() {
  const container = $('#checkout-items');
  if (!container.length) return;

  container.empty();

  if (!cart.length) {
    container.html('<div class="empty-state"><p>Your cart is empty.</p></div>');
    $('#checkout-total').text('0.00');
    return;
  }

  let subtotal = 0;

  cart.forEach(item => {
    const qty = item.quantity || 1;
    const itemTotal = Number(item.price || 0) * qty;
    subtotal += itemTotal;

    const html = `
      <div class="checkout-item">
        <div>
          <strong>${item.name}</strong>
          <div>Qty: ${qty}</div>
        </div>
        <div>$${itemTotal.toFixed(2)}</div>
      </div>
    `;
    container.append(html);
  });

  const shippingCost = calculateShippingCost();
  const total = subtotal + shippingCost;
  $('#checkout-total').text(total.toFixed(2));
}

function togglePaymentForm() {
  const method = $('input[name="payment-method"]:checked').val();
  $('.payment-form').hide();
  if (method) {
    $('#' + method + '-form').show();
  }
}

function formatCardNumber(input) {
  let value = input.val().replace(/\s+/g, '').replace(/[^0-9]/g, '');
  if (value.length > 16) value = value.substring(0, 16);

  let formatted = '';
  for (let i = 0; i < value.length; i++) {
    if (i > 0 && i % 4 === 0) formatted += ' ';
    formatted += value[i];
  }
  input.val(formatted);

  if (value.length === 16) {
    input.removeClass('error').addClass('success');
  } else if (value.length > 0) {
    input.addClass('error').removeClass('success');
  } else {
    input.removeClass('error success');
  }
}

function formatExpiryDate(input) {
  let value = input.val().replace(/[^0-9]/g, '');
  if (value.length > 4) value = value.substring(0, 4);

  if (value.length >= 3) {
    value = value.substring(0, 2) + '/' + value.substring(2);
  }
  input.val(value);

  if (isValidExpiryDate(value)) {
    input.removeClass('error').addClass('success');
  } else if (value.length > 0) {
    input.addClass('error').removeClass('success');
  } else {
    input.removeClass('error success');
  }
}

function formatCVV(input) {
  let value = input.val().replace(/[^0-9]/g, '');
  if (value.length > 4) value = value.substring(0, 4);
  input.val(value);

  if (value.length >= 3 && value.length <= 4) {
    input.removeClass('error').addClass('success');
  } else if (value.length > 0) {
    input.addClass('error').removeClass('success');
  } else {
    input.removeClass('error success');
  }
}

function validateCardholderName(input) {
  const value = (input.val() || '').trim();
  const nameRegex = /^[a-zA-Z\s]+$/;

  if (value.length >= 2 && nameRegex.test(value)) {
    input.removeClass('error').addClass('success');
    return true;
  } else if (value.length > 0) {
    input.addClass('error').removeClass('success');
    return false;
  } else {
    input.removeClass('error success');
    return false;
  }
}

function isValidExpiryDate(expiryDate) {
  if (!expiryDate || expiryDate.length !== 5 || expiryDate.indexOf('/') === -1) {
    return false;
  }

  const parts = expiryDate.split('/');
  const month = parseInt(parts[0], 10);
  const year = parseInt(parts[1], 10);

  if (isNaN(month) || isNaN(year)) return false;

  if (month < 1 || month > 12) return false;

  const now = new Date();
  const currentYear = now.getFullYear() % 100;
  const currentMonth = now.getMonth() + 1;

  if (year < currentYear) return false;
  if (year === currentYear && month < currentMonth) return false;

  return true;
}

function validateCreditCardForm() {
  const paymentMethod = $('input[name="payment-method"]:checked').val();

  if (paymentMethod !== 'credit-card') {
    return true;
  }

  const cardNumber = $('#card-number').val().replace(/\s+/g, '');
  const expiryDate = $('#expiry-date').val();
  const cvv = $('#cvv').val();
  const cardholderName = $('#cardholder-name').val().trim();

  let isValid = true;

  if (cardNumber.length !== 16 || !/^\d+$/.test(cardNumber)) {
    $('#card-number').addClass('error');
    isValid = false;
  }

  if (!isValidExpiryDate(expiryDate)) {
    $('#expiry-date').addClass('error');
    isValid = false;
  }

  if (cvv.length < 3 || cvv.length > 4 || !/^\d+$/.test(cvv)) {
    $('#cvv').addClass('error');
    isValid = false;
  }

  if (cardholderName.length < 2 || !/^[a-zA-Z\s]+$/.test(cardholderName)) {
    $('#cardholder-name').addClass('error');
    isValid = false;
  }

  return isValid;
}

function handleCheckout(e) {
  e.preventDefault();

  if (!cart.length) {
    showNotification('Your cart is empty', 'error');
    return;
  }

  if (!validateCreditCardForm()) {
    showNotification('Please check your payment information.', 'error');
    return;
  }

  const currentUser = getCurrentUser();
  if (!currentUser) {
    showNotification('Session expired. Please log in again.', 'error');
    window.location.href = 'index.html';
    return;
  }

  const shippingMethod = $('#shipping-method').val();
  const shippingAddress = $('#shipping-address').val();
  const paymentMethod = $('input[name="payment-method"]:checked').val();

  let subtotal = 0;
  const items = cart.map(item => {
    const qty = item.quantity || 1;
    const price = Number(item.price || 0);
    subtotal += price * qty;
    return {
      toyId: item.id,
      name: item.name,
      price: price,
      quantity: qty
    };
  });

  const shippingCost = calculateShippingCost();
  const total = subtotal + shippingCost;

  const newOrder = {
    id: generateOrderId(),
    customerEmail: currentUser.email,
    customerName: currentUser.name,
    items: items,
    subtotal: subtotal,
    shippingCost: shippingCost,
    total: total,
    status: 'pending',
    orderDate: new Date().toISOString().split('T')[0],
    estimatedDelivery: calculateEstimatedDelivery(shippingMethod),
    shippingAddress: shippingAddress,
    shippingMethod: shippingMethod,
    paymentMethod: paymentMethod
  };

  orders.push(newOrder);
  saveOrders();

  cart = [];
  saveCart();

  showOrderConfirmation(newOrder);
}


function showOrderConfirmation(order) {
  const modal = $('#order-confirm-modal');
  const content = $('#order-confirm-details');

  if (!modal.length || !content.length) {
    window.location.href = 'orders.html';
    return;
  }

  content.html(`
    <p><strong>Order ID:</strong> #${order.id}</p>
    <p><strong>Total Amount:</strong> $${order.total.toFixed(2)}</p>
    <p><strong>Estimated Delivery:</strong> ${order.estimatedDelivery}</p>
    <p><strong>Shipping Address:</strong> ${order.shippingAddress}</p>
    <div class="progress-tracker">
      <div class="progress-step step-completed">
        <div class="step-icon">✓</div>
        <div>Order Placed</div>
      </div>
      <div class="progress-step step-active">
        <div class="step-icon">2</div>
        <div>Confirmed</div>
      </div>
      <div class="progress-step">
        <div class="step-icon">3</div>
        <div>Processing</div>
      </div>
      <div class="progress-step">
        <div class="step-icon">4</div>
        <div>Shipped</div>
      </div>
      <div class="progress-step">
        <div class="step-icon">5</div>
        <div>Delivered</div>
      </div>
    </div>
  `);

  modal.removeClass('hidden');
}

function closeModal() {
  $('.modal').addClass('hidden');
}

function viewOrderTracking() {
  closeModal();
  window.location.href = 'orders.html';
}

function continueShopping() {
  closeModal();
  window.location.href = 'order-system.html';
}

// --- logout helper ---

function logout() {
  const ok = window.confirm('Are you sure you want to log out?');
  if (!ok) return;

  // Back to login / landing
  window.location.href = '../index.html';
}

$(document).ready(function () {
  const user = requireAuth();
  if (!user) return;

  loadState();
  updateWishlistCount();
  updateCartCount();
  loadCheckoutSummary();

  $('input[name="payment-method"]').on('change', togglePaymentForm);

  $('#card-number').on('input', function () {
    formatCardNumber($(this));
  });

  $('#expiry-date').on('input', function () {
    formatExpiryDate($(this));
  });

  $('#cvv').on('input', function () {
    formatCVV($(this));
  });

  $('#cardholder-name').on('input', function () {
    validateCardholderName($(this));
  });

  $('#shipping-method').on('change', loadCheckoutSummary);

  $('#checkout-form').on('submit', handleCheckout);

  togglePaymentForm();
});

window.closeModal = closeModal;
window.viewOrderTracking = viewOrderTracking;
window.continueShopping = continueShopping;
