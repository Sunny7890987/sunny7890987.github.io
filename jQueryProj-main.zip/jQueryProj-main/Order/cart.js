const STORAGE_WISHLIST = 'wishlist';
const STORAGE_CART = 'cart';
const STORAGE_ORDERS = 'orders';

let wishlist = [];
let cart = [];

function getCurrentUser() {
  const raw = localStorage.getItem('currentUser');
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return null;
  }
  $('#current-user-name').text(user.name || '');
  return user;
}

function loadState() {
  try {
    wishlist = JSON.parse(localStorage.getItem(STORAGE_WISHLIST)) || [];
  } catch (e) {
    wishlist = [];
  }
  try {
    cart = JSON.parse(localStorage.getItem(STORAGE_CART)) || [];
  } catch (e) {
    cart = [];
  }
}

function saveCart() {
  localStorage.setItem(STORAGE_CART, JSON.stringify(cart));
  updateCartCount();
}

function updateWishlistCount() {
  const count = wishlist.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.wishlist-count').text(count);
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.cart-count').text(count);
}

function showNotification(message, type = 'info') {
  const prefix = type ? `[${type.toUpperCase()}] ` : '';

  if (type === 'error') {
    console.error(prefix + message);
  } else {
    console.log(prefix + message);
  }
}

// --- Cart rendering ---
function loadOrderSummary() {
  const summary = $('#order-summary');
  const btnClear = $('#btn-clear-cart');
  const btnCheckout = $('#btn-checkout');

  if (!summary.length) return;

  summary.empty();

  if (!cart.length) {
    summary.html('<div class="empty-state"><p>Your cart is empty.</p></div>');

    if (btnClear.length) btnClear.hide();
    if (btnCheckout.length) btnCheckout.hide();
    return;
  }

  // cart has items → show the extra buttons
  if (btnClear.length) btnClear.show();
  if (btnCheckout.length) btnCheckout.show();

  let total = 0;

  cart.forEach(item => {
    const qty = item.quantity || 1;
    const price = Number(item.price || 0);
    const itemTotal = price * qty;
    total += itemTotal;

    const html = `
      <div class="order-item">
        <div>
          <strong>${item.name}</strong>
          <div>${item.category || ''}${item.ageRange ? ' • ' + item.ageRange + ' years' : ''}</div>
        </div>
        <div class="quantity-controls">
          <button class="quantity-btn" onclick="decreaseCartItem(${item.id})">-</button>
          <span>${qty}</span>
          <button class="quantity-btn" onclick="increaseCartItem(${item.id})">+</button>
        </div>
        <div style="text-align:right;">
          <div>$${price.toFixed(2)} each</div>
          <div><strong>$${itemTotal.toFixed(2)}</strong></div>
          <button class="btn btn-outline" onclick="removeFromCart(${item.id})">Remove</button>
        </div>
      </div>
    `;
    summary.append(html);
  });

  summary.append(`
    <div class="order-total">
      <strong>Total: $${total.toFixed(2)}</strong>
    </div>
  `);
}

function increaseCartItem(id) {
  const item = cart.find(i => i.id === id);
  if (!item) return;

  item.quantity = (item.quantity || 1) + 1;
  saveCart();
  updateCartCount();
  loadOrderSummary();
}

function decreaseCartItem(id) {
  const item = cart.find(i => i.id === id);
  if (!item) return;

  const current = item.quantity || 1;
  if (current <= 1) {
    // At 1 → treat as remove, with confirmation
    removeFromCart(id);
    return;
  }

  item.quantity = current - 1;
  saveCart();
  updateCartCount();
  loadOrderSummary();
}

function removeFromCart(id) {
  const item = cart.find(i => i.id === id);
  if (!item) return;

  const ok = window.confirm(`Remove "${item.name}" from your cart?`);
  if (!ok) return;

  cart = cart.filter(i => i.id !== id);
  saveCart();
  updateCartCount();
  loadOrderSummary();
  showNotification('Item removed from cart', 'success');
}

function clearCart() {
  if (!cart.length) {
    showNotification('Your cart is already empty', 'info');
    return;
  }

  const ok = window.confirm('Are you sure you want to clear your entire cart?');
  if (!ok) return;

  cart = [];
  saveCart();
  updateCartCount();
  loadOrderSummary();
  showNotification('Cart cleared', 'success');
}

function proceedToCheckout() {
  if (!cart.length) {
    showNotification('Your cart is empty', 'error');
    return;
  }
  window.location.href = 'checkout.html';
}

// --- logout helper ---

function logout() {
  const ok = window.confirm('Are you sure you want to log out?');
  if (!ok) return;

  // Back to login / landing
  window.location.href = '../index.html';
}

// --- Initialisation ---

$(document).ready(function () {
  const user = requireAuth();
  if (!user) return;

  loadState();
  updateWishlistCount();
  updateCartCount();
  loadOrderSummary();
});

// Expose for inline handlers
window.proceedToCheckout = proceedToCheckout;
window.loadOrderSummary = loadOrderSummary;
window.increaseCartItem = increaseCartItem;
window.decreaseCartItem = decreaseCartItem;
window.removeFromCart = removeFromCart;
window.clearCart = clearCart;
