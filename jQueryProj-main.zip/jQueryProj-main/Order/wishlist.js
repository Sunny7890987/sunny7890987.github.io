const STORAGE_WISHLIST = 'wishlist';
const STORAGE_CART = 'cart';
const STORAGE_ORDERS = 'orders';

let wishlist = [];
let cart = [];

function getCurrentUser() {
  const raw = localStorage.getItem('currentUser');
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return null;
  }
  $('#current-user-name').text(user.name || '');
  return user;
}

function loadState() {
  try {
    wishlist = JSON.parse(localStorage.getItem(STORAGE_WISHLIST)) || [];
  } catch (e) {
    wishlist = [];
  }
  try {
    cart = JSON.parse(localStorage.getItem(STORAGE_CART)) || [];
  } catch (e) {
    cart = [];
  }
}

function saveWishlist() {
  localStorage.setItem(STORAGE_WISHLIST, JSON.stringify(wishlist));
  updateWishlistCount();
}

function saveCart() {
  localStorage.setItem(STORAGE_CART, JSON.stringify(cart));
  updateCartCount();
}

function updateWishlistCount() {
  const count = wishlist.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.wishlist-count').text(count);
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  $('.cart-count').text(count);
}

function showNotification(message, type = 'info') {
  const prefix = type ? `[${type.toUpperCase()}] ` : '';

  if (type === 'error') {
    console.error(prefix + message);
  } else {
    console.log(prefix + message);
  }
}

// --- Wishlist rendering ---

function renderWishlist() {
  const container = $('#wishlist-items');
  const emptyState = $('#empty-wishlist');

  if (!container.length) return;

  container.empty();

  if (!wishlist.length) {
    container.hide();
    emptyState.show();
    return;
  }

  emptyState.hide();
  container.show();

  wishlist.forEach(item => {
    const html = `
      <div class="wishlist-item">
        <div class="wishlist-item-image">
          ${item.image}
        </div>
        <div class="wishlist-item-details">
          <div class="wishlist-item-name">${item.name}</div>
          <div class="wishlist-item-meta">
            ${item.category}${item.ageRange ? ' • ' + item.ageRange + ' years' : ''}
          </div>
          <div class="wishlist-item-price">
            $${Number(item.price || 0).toFixed(2)}
          </div>
        </div>
        <div class="wishlist-item-actions">
          <button class="btn btn-primary" onclick="moveWishlistItemToCart(${item.id})">
            Order Now
          </button>
          <button class="btn btn-outline" onclick="removeFromWishlist(${item.id})">
            Remove
          </button>
        </div>
      </div>
    `;
    container.append(html);
  });
}


function removeFromWishlist(id) {
  const item = wishlist.find(i => i.id === id);
  if (!item) return;

  const ok = window.confirm(`Remove "${item.name}" from your wishlist?`);
  if (!ok) return;

  wishlist = wishlist.filter(i => i.id !== id);
  saveWishlist();
  renderWishlist();
  if (typeof updateWishlistCount === 'function') {
    updateWishlistCount();
  }
  showNotification('Removed from wishlist', 'success');
}

function moveWishlistItemToCart(toyId) {
  const index = wishlist.findIndex(item => item.id === toyId);
  if (index === -1) {
    showNotification('Item not found in wishlist', 'error');
    return;
  }

  const item = wishlist[index];
  const qty = item.quantity || 1;

  const existing = cart.find(c => c.id === toyId);
  if (existing) {
    existing.quantity = (existing.quantity || 1) + qty;
  } else {
    cart.push({ ...item });
  }

  wishlist.splice(index, 1);

  saveWishlist();
  saveCart();
  renderWishlist();
  showNotification('Moved to cart', 'success');
  window.location.href = 'cart.html';
}

// --- logout helper ---

function logout() {
  const ok = window.confirm('Are you sure you want to log out?');
  if (!ok) return;

  // Back to login / landing
  window.location.href = '../index.html';
}

// --- Initialisation ---

$(document).ready(function () {
  const user = requireAuth();
  if (!user) return;

  loadState();
  updateWishlistCount();
  updateCartCount();
  renderWishlist();
});

// Expose for inline handlers
window.removeFromWishlist = removeFromWishlist;
window.moveWishlistItemToCart = moveWishlistItemToCart;
